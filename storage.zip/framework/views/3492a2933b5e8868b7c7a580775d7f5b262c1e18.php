<?php echo $__env->yieldPushContent($name . '_input_start'); ?>

<div class="form-group <?php echo e($col); ?> <?php echo e(isset($attributes['required']) ? 'required' : ''); ?> <?php echo e($errors->has($name) ? 'has-error' : ''); ?>">
    <?php echo Form::label($name, $text, ['class' => 'control-label']); ?>

    <div class="input-group">
        <div class="btn-group radio-inline" data-toggle="buttons">
            <label id="<?php echo e($name); ?>_1" class="btn btn-default">
                <?php echo Form::radio($name, '1'); ?>

                <span class="radiotext"><?php echo e(trans('general.yes')); ?></span>
            </label>
            <label id="<?php echo e($name); ?>_0" class="btn btn-default">
                <?php echo Form::radio($name, '0', true); ?>

                <span class="radiotext"><?php echo e(trans('general.no')); ?></span>
            </label>
        </div>
    </div>
    <?php echo $errors->first($name, '<p class="help-block">:message</p>'); ?>

</div>

<?php echo $__env->yieldPushContent($name . '_input_end'); ?>
