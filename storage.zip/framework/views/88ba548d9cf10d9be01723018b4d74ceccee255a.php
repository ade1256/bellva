<html lang="<?php echo e(setting('general.default_locale')); ?>">
    <?php echo $__env->make('partials.modules.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <body class="hold-transition <?php echo e(setting('general.admin_theme', 'skin-green-light')); ?> sidebar-mini fixed">
        <?php echo $__env->yieldPushContent('body_start'); ?>

        <!-- Site wrapper -->
        <div class="wrapper">
            <?php echo $__env->make('partials.admin.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <?php echo $__env->make('partials.admin.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <?php echo $__env->make('partials.admin.content', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <?php echo $__env->make('partials.admin.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>

        <?php echo $__env->yieldPushContent('body_end'); ?>
    </body>
</html>
