<tr id="currency-edit">
    <td>
        <?php echo e(Form::textGroup('name', trans('general.name'), 'id-card-o', [], $item->name, '')); ?>

    </td>
    <td class="hidden-xs">
        <?php echo e(Form::selectGroup('code', trans('currencies.code'), 'code', $codes, $item->code, [], '')); ?>

    </td>
    <td>
        <?php echo e(Form::textGroup('rate', trans('currencies.rate'), 'money', [], $item->rate, '')); ?>

    </td>
    <td class="hidden-xs">
        <?php echo e(Form::radioGroup('enabled', trans('general.enabled'), trans('general.yes'), trans('general.no'), [], 'col-md-12')); ?>

    </td>
    <td class="text-center">
        <?php echo Form::button('<span class="fa fa-save"></span>', ['type' => 'button', 'class' => 'btn btn-success  currency-updated', 'data-loading-text' => trans('general.loading'), 'data-href' => url('wizard/currencies/' . $item->id), 'data-id' => $item->id, 'style' => 'padding: 9px 14px; margin-top: 10px;']); ?>

    </td>
    <td class="hidden">
        <?php echo e(Form::numberGroup('precision', trans('currencies.precision'), 'bullseye', [], $item->precision)); ?>


        <?php echo e(Form::textGroup('symbol', trans('currencies.symbol.symbol'), 'font', [], $item->symbol, '')); ?>


        <?php echo e(Form::selectGroup('symbol_first', trans('currencies.symbol.position'), 'text-width', ['1' => trans('currencies.symbol.before'), '0' => trans('currencies.symbol.after')], $item->symbol_first)); ?>


        <?php echo e(Form::textGroup('decimal_mark', trans('currencies.decimal_mark'), 'columns', [], $item->decimal_mark, '')); ?>


        <?php echo e(Form::textGroup('thousands_separator', trans('currencies.thousands_separator'), 'columns', [], $item->thousands_separator)); ?>


        <?php echo e(Form::radioGroup('default_currency', trans('currencies.default'))); ?>


        <?php echo e(Form::hidden('id', $item->id)); ?>

    </td>
</tr>