<?php $__env->startSection('title', trans('import.title', ['type' => trans_choice('general.' . $type, 2)])); ?>

<?php $__env->startSection('content'); ?>
    <div class="box box-success">
        <?php echo Form::open(['url' => $path . '/import', 'files' => true, 'role' => 'form', 'class' => 'form-loading-button']); ?>


        <div class="box-body">
            <div class="col-md-12">
                <div class="alert alert-info alert-important">
                    <?php echo trans('import.message', ['link' => url('public/files/import/' . $type . '.xlsx')]); ?>

                </div>
            </div>
            <?php echo $__env->yieldPushContent('import_input_start'); ?>
            <div class="form-group col-md-12 required <?php echo e($errors->has('import') ? 'has-error' : ''); ?>" style="min-height: 59px">
                <?php echo Form::label('import', trans('general.form.select.file'), ['class' => 'control-label']); ?>

                <?php echo Form::file('import', null, ['class' => 'form-control']); ?>

                <?php echo $errors->first('import', '<p class="help-block">:message</p>'); ?>

            </div>
            <?php echo $__env->yieldPushContent('import_input_end'); ?>
        </div>
        <!-- /.box-body -->

        <div class="box-footer">
            <div class="col-md-12">
                <div class="form-group no-margin">
                    <?php echo Form::button('<span class="fa fa-download"></span> &nbsp;' . trans('import.import'), ['type' => 'submit', 'class' => 'btn btn-success']); ?>

                    <a href="<?php echo e(url($path)); ?>" class="btn btn-default"><span class="fa fa-times-circle"></span> &nbsp;<?php echo e(trans('general.cancel')); ?></a>
                </div>
            </div>
        </div>

        <?php echo Form::close(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('public/js/bootstrap-fancyfile.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('public/css/bootstrap-fancyfile.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    $(document).ready(function(){
        $('#import').fancyfile({
            text  : '<?php echo e(trans('general.form.select.file')); ?>',
            style : 'btn-default',
            placeholder : '<?php echo e(trans('general.form.no_file_selected')); ?>'
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>