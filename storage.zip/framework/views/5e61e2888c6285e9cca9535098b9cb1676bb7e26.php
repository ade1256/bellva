<?php $__env->startSection('title', trans_choice('general.items', 2)); ?>

<?php $__env->startSection('new_button'); ?>
<?php if (app('laratrust')->can('create-common-items')) : ?>
<span class="new-button"><a href="<?php echo e(route('items.create')); ?>" class="btn btn-success btn-sm"><span class="fa fa-plus"></span> &nbsp;<?php echo e(trans('general.add_new')); ?></a></span>
<span><a href="<?php echo e(route('import.create', ['common', 'items'])); ?>" class="btn btn-default btn-sm"><span class="fa fa-download"></span> &nbsp;<?php echo e(trans('import.import')); ?></a></span>
<?php endif; // app('laratrust')->can ?>
<span><a href="<?php echo e(route('items.export', request()->input())); ?>" class="btn btn-default btn-sm"><span class="fa fa-upload"></span> &nbsp;<?php echo e(trans('general.export')); ?></a></span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Default box -->
<div class="box box-success">
    <div class="box-header with-border">
        <?php echo Form::open(['route' => 'items.index', 'role' => 'form', 'method' => 'GET']); ?>

        <div id="items" class="pull-left box-filter">
            <span class="title-filter hidden-xs"><?php echo e(trans('general.search')); ?>:</span>
            <?php echo Form::text('search', request('search'), ['class' => 'form-control input-filter input-sm', 'placeholder' => trans('general.search_placeholder')]); ?>

            <?php echo Form::select('categories[]', $categories, request('categories'), ['id' => 'filter-categories', 'class' => 'form-control input-filter input-lg', 'multiple' => 'multiple']); ?>

            <?php echo Form::button('<span class="fa fa-filter"></span> &nbsp;' . trans('general.filter'), ['type' => 'submit', 'class' => 'btn btn-sm btn-default btn-filter']); ?>

        </div>
        <div class="pull-right">
            <span class="title-filter hidden-xs"><?php echo e(trans('general.show')); ?>:</span>
            <?php echo Form::select('limit', $limits, request('limit', setting('general.list_limit', '25')), ['class' => 'form-control input-filter input-sm', 'onchange' => 'this.form.submit()']); ?>

        </div>
        <?php echo Form::close(); ?>

    </div>
    <!-- /.box-header -->

    <div class="box-body">
        <div class="table table-responsive">
            <table class="table table-striped table-hover" id="tbl-items">
                <thead>
                    <tr>
                        <th class="col-md-1 hidden-xs"><?php echo e(trans_choice('general.pictures', 1)); ?></th>
                        <th class="col-md-3"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('name', trans('general.name')));?></th>
                        <th class="col-md-1 hidden-xs"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('category', trans_choice('general.categories', 1)));?></th>
                        <th class="col-md-1 hidden-xs"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('quantity', trans_choice('items.quantities', 1)));?></th>
                        <th class="col-md-2 text-right amount-space"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('sale_price', trans('items.sales_price')));?></th>
                        <th class="col-md-2 hidden-xs text-right amount-space"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('purchase_price', trans('items.purchase_price')));?></th>
                        <th class="col-md-1 hidden-xs"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('enabled', trans_choice('general.statuses', 1)));?></th>
                        <th class="col-md-1 text-center"><?php echo e(trans('general.actions')); ?></th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="hidden-xs"><img src="<?php echo e($item->picture ? Storage::url($item->picture->id) : asset('public/img/logo.png')); ?>" class="img-thumbnail" width="50" alt="<?php echo e($item->name); ?>"></td>
                        <td><a href="<?php echo e(route('items.edit', $item->id)); ?>"><?php echo e($item->name); ?></a></td>
                        <td class="hidden-xs"><?php echo e($item->category ? $item->category->name : trans('general.na')); ?></td>
                        <td class="hidden-xs"><?php echo e($item->quantity); ?></td>
                        <td class="text-right amount-space"><?php echo e(money($item->sale_price, setting('general.default_currency'), true)); ?></td>
                        <td class="hidden-xs text-right amount-space"><?php echo e(money($item->purchase_price, setting('general.default_currency'), true)); ?></td>
                        <td class="hidden-xs">
                            <?php if($item->enabled): ?>
                                <span class="label label-success"><?php echo e(trans('general.enabled')); ?></span>
                            <?php else: ?>
                                <span class="label label-danger"><?php echo e(trans('general.disabled')); ?></span>
                            <?php endif; ?>
                        </td>
                        <td class="text-center">
                            <div class="btn-group">
                                <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" data-toggle-position="left" aria-expanded="false">
                                    <i class="fa fa-ellipsis-h"></i>
                                </button>
                                <ul class="dropdown-menu dropdown-menu-right">
                                    <li><a href="<?php echo e(route('items.edit', $item->id)); ?>"><?php echo e(trans('general.edit')); ?></a></li>
                                    <?php if($item->enabled): ?>
                                        <li><a href="<?php echo e(route('items.disable', $item->id)); ?>"><?php echo e(trans('general.disable')); ?></a></li>
                                    <?php else: ?>
                                        <li><a href="<?php echo e(route('items.enable', $item->id)); ?>"><?php echo e(trans('general.enable')); ?></a></li>
                                    <?php endif; ?>
                                    <?php if (app('laratrust')->can('create-common-items')) : ?>
                                    <li class="divider"></li>
                                    <li><a href="<?php echo e(route('items.duplicate', $item->id)); ?>"><?php echo e(trans('general.duplicate')); ?></a></li>
                                    <?php endif; // app('laratrust')->can ?>
                                    <?php if (app('laratrust')->can('delete-common-items')) : ?>
                                    <li class="divider"></li>
                                    <li><?php echo Form::deleteLink($item, 'common/items'); ?></li>
                                    <?php endif; // app('laratrust')->can ?>
                                </ul>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <!-- /.box-body -->

    <div class="box-footer">
        <?php echo $__env->make('partials.admin.pagination', ['items' => $items, 'type' => 'items'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <!-- /.box-footer -->
</div>
<!-- /.box -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    $(document).ready(function(){
        $("#filter-categories").select2({
            placeholder: "<?php echo e(trans('general.form.select.field', ['field' => trans_choice('general.categories', 1)])); ?>"
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>