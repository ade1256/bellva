<ul class="<?php echo e(config('language.flags.ul_class')); ?>">
<?php $__currentLoopData = language()->allowed(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li class="<?php echo e(config('language.flags.li_class')); ?>">
        <a href="<?php echo e(language()->back($code)); ?>">
            <img src="<?php echo e(asset('vendor/akaunting/language/src/Resources/assets/img/flags/'. language()->country($code) .'.png')); ?>" alt="<?php echo e($name); ?>" width="<?php echo e(config('language.flags.width')); ?>" /> &nbsp; <?php echo e($name); ?>

        </a>
    </li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>