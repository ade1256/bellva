<?php $__env->startSection('title', trans('reports.profit_loss')); ?>

<?php $__env->startSection('new_button'); ?>
<span class="new-button"><a href="<?php echo e(url('reports/profit-loss')); ?>?print=1&status=<?php echo e(request('status')); ?>&year=<?php echo e(request('year', $this_year)); ?>" target="_blank" class="btn btn-success btn-sm"><span class="fa fa-print"></span> &nbsp;<?php echo e(trans('general.print')); ?></a></span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Default box -->
<div class="box box-success">
    <div class="box-header with-border">
        <?php echo Form::open(['url' => 'reports/profit-loss', 'role' => 'form', 'method' => 'GET']); ?>

        <div id="items" class="pull-left" style="margin-left: 5px">
            <?php echo Form::select('year', $years, request('year', $this_year), ['class' => 'form-control input-filter input-sm']); ?>

            <?php echo Form::select('status', $statuses, request('status'), ['class' => 'form-control input-filter input-sm']); ?>

            <?php echo Form::button('<span class="fa fa-filter"></span> &nbsp;' . trans('general.filter'), ['type' => 'submit', 'class' => 'btn btn-sm btn-default btn-filter']); ?>

        </div>
        <?php echo Form::close(); ?>

    </div>

    <?php echo $__env->make('reports.profit_loss.body', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<!-- /.box -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>