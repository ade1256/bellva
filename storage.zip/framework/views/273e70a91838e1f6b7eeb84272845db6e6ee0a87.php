<tr id="item-row-<?php echo e($item_row); ?>">
    <?php echo $__env->yieldPushContent('actions_td_start'); ?>
    <td class="text-center" style="vertical-align: middle;">
        <?php echo $__env->yieldPushContent('actions_button_start'); ?>
        <button type="button" onclick="$(this).tooltip('destroy'); $('#item-row-<?php echo e($item_row); ?>').remove(); totalItem();" data-toggle="tooltip" title="<?php echo e(trans('general.delete')); ?>" class="btn btn-xs btn-danger"><i class="fa fa-trash"></i></button>
        <?php echo $__env->yieldPushContent('actions_button_end'); ?>
    </td>
    <?php echo $__env->yieldPushContent('actions_td_end'); ?>
    <?php echo $__env->yieldPushContent('name_td_start'); ?>
    <td <?php echo $errors->has('item.' . $item_row . '.name') ? 'class="has-error"' : ''; ?>>
        <?php echo $__env->yieldPushContent('name_input_start'); ?>
        <input value="<?php echo e(empty($item) ? '' : $item->name); ?>" class="form-control typeahead" required="required" placeholder="<?php echo e(trans('general.form.enter', ['field' => trans_choice('invoices.item_name', 1)])); ?>" name="item[<?php echo e($item_row); ?>][name]" type="text" id="item-name-<?php echo e($item_row); ?>" autocomplete="off">
        <input value="<?php echo e(empty($item) ? '' : $item->item_id); ?>" name="item[<?php echo e($item_row); ?>][item_id]" type="hidden" id="item-id-<?php echo e($item_row); ?>">
        <?php echo $errors->first('item.' . $item_row . '.name', '<p class="help-block">:message</p>'); ?>

        <?php echo $__env->yieldPushContent('name_input_end'); ?>
    </td>
    <?php echo $__env->yieldPushContent('name_td_end'); ?>
    <?php echo $__env->yieldPushContent('quantity_td_start'); ?>
    <td <?php echo e($errors->has('item.' . $item_row . '.quantity') ? 'class="has-error"' : ''); ?>>
        <?php echo $__env->yieldPushContent('quantity_input_start'); ?>
        <input value="<?php echo e(empty($item) ? '' : $item->quantity); ?>" class="form-control text-center" required="required" name="item[<?php echo e($item_row); ?>][quantity]" type="text" id="item-quantity-<?php echo e($item_row); ?>">
        <?php echo $errors->first('item.' . $item_row . '.quantity', '<p class="help-block">:message</p>'); ?>

        <?php echo $__env->yieldPushContent('quantity_input_end'); ?>
    </td>
    <?php echo $__env->yieldPushContent('quantity_td_end'); ?>
    <?php echo $__env->yieldPushContent('price_td_start'); ?>
    <td <?php echo e($errors->has('item.' . $item_row . 'price') ? 'class="has-error"' : ''); ?>>
        <?php echo $__env->yieldPushContent('price_input_start'); ?>
        <input value="<?php echo e(empty($item) ? '' : $item->price); ?>" class="form-control text-right input-price" required="required" name="item[<?php echo e($item_row); ?>][price]" type="text" id="item-price-<?php echo e($item_row); ?>">
        <input value="<?php echo e($currency->code); ?>" name="item[<?php echo e($item_row); ?>][currency]" type="hidden" id="item-currency-<?php echo e($item_row); ?>">
        <?php echo $errors->first('item.' . $item_row . 'price', '<p class="help-block">:message</p>'); ?>

        <?php echo $__env->yieldPushContent('price_input_end'); ?>
    </td>
    <?php echo $__env->yieldPushContent('price_td_end'); ?>
    <?php echo $__env->yieldPushContent('taxes_td_start'); ?>
    <td <?php echo e($errors->has('item.' . $item_row . '.tax_id') ? 'class="has-error"' : ''); ?>>
        <?php echo $__env->yieldPushContent('tax_id_input_start'); ?>
        <?php echo Form::select('item[' . $item_row . '][tax_id][]', $taxes, (empty($item) || empty($item->tax_id)) ? setting('general.default_tax') : $item->tax_id, ['id'=> 'item-tax-'. $item_row, 'class' => 'form-control tax-select2', 'multiple' => 'true']); ?>

        <?php echo $errors->first('item.' . $item_row . '.tax_id', '<p class="help-block">:message</p>'); ?>

        <?php echo $__env->yieldPushContent('tax_id_input_end'); ?>
    </td>
    <?php echo $__env->yieldPushContent('taxes_td_end'); ?>
    <?php echo $__env->yieldPushContent('total_td_start'); ?>
    <td class="text-right" style="vertical-align: middle;">
        <?php echo $__env->yieldPushContent('total_input_start'); ?>
        <?php if(empty($item) || !isset($item->total)): ?>
        <span id="item-total-<?php echo e($item_row); ?>">0</span>
        <?php else: ?>
        <span id="item-total-<?php echo e($item_row); ?>"><?php echo money($item->total, $invoice->currency_code, true); ?></span>
        <?php endif; ?>
        <?php echo $__env->yieldPushContent('total_input_end'); ?>
    </td>
    <?php echo $__env->yieldPushContent('total_td_end'); ?>
</tr>
