<?php echo $__env->yieldPushContent('menu_start'); ?>

<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
        <!-- Sidebar user panel -->
        <div class="user-panel">
            <div class="pull-left image">
                <img src="<?php echo e(setting('general.company_logo') ? Storage::url(setting('general.company_logo')) : asset('public/img/logo.png')); ?>" class="img-circle" alt="<?php echo setting('general.company_name'); ?>">
            </div>
            <div class="pull-left info">
                <p><?php echo e(str_limit(setting('general.company_name'), 22)); ?></p>
                <?php if (app('laratrust')->can('read-common-companies')) : ?>
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span class="caret"></span> &nbsp;<?php echo e(trans('general.switch')); ?></a>
                <ul class="dropdown-menu">
                    <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $com): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="<?php echo e(url('common/companies/'. $com->id .'/set')); ?>"><?php echo e(str_limit($com->company_name, 18)); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if (app('laratrust')->can('update-common-companies')) : ?>
                    <li role="separator" class="divider"></li>
                    <li><a href="<?php echo e(url('common/companies')); ?>"><?php echo e(trans('companies.manage')); ?></a></li>
                    <?php endif; // app('laratrust')->can ?>
                </ul>
                <?php endif; // app('laratrust')->can ?>
            </div>
        </div>
        <!-- search form -->
        <form action="#" method="get" id="form-search" class="sidebar-form">
            <div id="live-search" class="input-group">
                <input type="text" name="live-search" value="<?php //echo $search; ?>" id="input-search" class="form-control" placeholder="Search...">
                <span class="input-group-btn">
                    <button type="submit" name="live-search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i></button>
                </span>
            </div>
        </form>
        <!-- /.search form -->
        <!-- sidebar menu: : style can be found in sidebar.less -->
        <?php echo Menu::get('AdminMenu'); ?>

    </section>
    <!-- /.sidebar -->
</aside>

<?php echo $__env->yieldPushContent('menu_end'); ?>