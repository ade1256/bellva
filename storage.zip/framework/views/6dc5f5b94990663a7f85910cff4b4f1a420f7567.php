<?php $__env->startSection('title', trans('general.title.edit', ['type' => trans_choice('general.items', 1)])); ?>

<?php $__env->startSection('content'); ?>
<!-- Default box -->
<div class="box box-success">
    <?php echo Form::model($item, [
        'method' => 'PATCH',
        'files' => true,
        'route' => ['items.update', $item->id],
        'role' => 'form',
        'class' => 'form-loading-button'
    ]); ?>


    <div class="box-body">
        <?php echo e(Form::textGroup('name', trans('general.name'), 'id-card-o')); ?>


        <?php echo e(Form::textGroup('sku', trans('items.sku'), 'key')); ?>


        <?php echo e(Form::textareaGroup('description', trans('general.description'))); ?>


        <?php echo e(Form::textGroup('sale_price', trans('items.sales_price'), 'money')); ?>


        <?php echo e(Form::textGroup('purchase_price', trans('items.purchase_price'), 'money')); ?>


        <?php echo e(Form::textGroup('quantity', trans_choice('items.quantities', 1), 'cubes')); ?>


        <?php echo e(Form::selectGroup('tax_id', trans_choice('general.taxes', 1), 'percent', $taxes, null, [])); ?>


        <?php echo e(Form::selectGroup('category_id', trans_choice('general.categories', 1), 'folder-open-o', $categories, null, [])); ?>


        <?php echo e(Form::fileGroup('picture', trans_choice('general.pictures', 1))); ?>


        <?php echo e(Form::radioGroup('enabled', trans('general.enabled'))); ?>

    </div>
    <!-- /.box-body -->

    <?php if (app('laratrust')->can('update-common-items')) : ?>
    <div class="box-footer">
        <?php echo e(Form::saveButtons('common/items')); ?>

    </div>
    <!-- /.box-footer -->
    <?php endif; // app('laratrust')->can ?>
    <?php echo Form::close(); ?>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('public/js/bootstrap-fancyfile.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('public/css/bootstrap-fancyfile.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript">
        var text_yes = '<?php echo e(trans('general.yes')); ?>';
        var text_no = '<?php echo e(trans('general.no')); ?>';

        $(document).ready(function(){
            /*$("#sale_price").maskMoney({
                thousands : '<?php echo e($currency->thousands_separator); ?>',
                decimal : '<?php echo e($currency->decimal_mark); ?>',
                precision : <?php echo e($currency->precision); ?>,
                allowZero : true,
                <?php if($currency->symbol_first): ?>
                prefix : '<?php echo e($currency->symbol); ?>'
                <?php else: ?>
                suffix : '<?php echo e($currency->symbol); ?>'
                <?php endif; ?>
            });

            $("#purchase_price").maskMoney({
                thousands : '<?php echo e($currency->thousands_separator); ?>',
                decimal : '<?php echo e($currency->decimal_mark); ?>',
                precision : <?php echo e($currency->precision); ?>,
                allowZero : true,
                <?php if($currency->symbol_first): ?>
                prefix : '<?php echo e($currency->symbol); ?>'
                <?php else: ?>
                suffix : '<?php echo e($currency->symbol); ?>'
                <?php endif; ?>
            });

            $("#sale_price").focusout();
            $("#purchase_price").focusout();*/

            $("#tax_id").select2({
                placeholder: {
                    id: '-1', // the value of the option
                    text: "<?php echo e(trans('general.form.select.field', ['field' => trans_choice('general.taxes', 1)])); ?>"
                }
            });

            $("#category_id").select2({
                placeholder: "<?php echo e(trans('general.form.select.field', ['field' => trans_choice('general.categories', 1)])); ?>"
            });

            $('#picture').fancyfile({
                text  : '<?php echo e(trans('general.form.select.file')); ?>',
                style : 'btn-default',
                <?php if($item->picture): ?>
                placeholder : '<?php echo $item->picture->basename; ?>'
                <?php else: ?>
                placeholder : '<?php echo e(trans('general.form.no_file_selected')); ?>'
                <?php endif; ?>
            });

            <?php if($item->picture): ?>
                picture_html  = '<span class="picture">';
                picture_html += '    <a href="<?php echo e(url('uploads/' . $item->picture->id . '/download')); ?>">';
                picture_html += '        <span id="download-picture" class="text-primary">';
                picture_html += '            <i class="fa fa-file-<?php echo e($item->picture->aggregate_type); ?>-o"></i> <?php echo e($item->picture->basename); ?>';
                picture_html += '        </span>';
                picture_html += '    </a>';
                picture_html += '    <?php echo Form::open(['id' => 'picture-' . $item->picture->id, 'method' => 'DELETE', 'url' => [url('uploads/' . $item->picture->id)], 'style' => 'display:inline']); ?>';
                picture_html += '    <a id="remove-picture" href="javascript:void();">';
                picture_html += '        <span class="text-danger"><i class="fa fa fa-times"></i></span>';
                picture_html += '    </a>';
                picture_html += '    <?php echo Form::close(); ?>';
                picture_html += '</span>';
    
                $('.fancy-file .fake-file').append(picture_html);
    
                $(document).on('click', '#remove-picture', function (e) {
                    confirmDelete("#picture-<?php echo $item->picture->id; ?>", "<?php echo trans('general.attachment'); ?>", "<?php echo trans('general.delete_confirm', ['name' => '<strong>' . $item->picture->basename . '</strong>', 'type' => strtolower(trans('general.attachment'))]); ?>", "<?php echo trans('general.cancel'); ?>", "<?php echo trans('general.delete'); ?>");
                });
            <?php endif; ?>
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>