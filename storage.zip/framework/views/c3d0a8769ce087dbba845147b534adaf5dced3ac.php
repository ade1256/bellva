<head>
    <?php echo $__env->yieldPushContent('head_start'); ?>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8; charset=ISO-8859-1"/>

    <title><?php echo $__env->yieldContent('title'); ?> - <?php echo setting('general.company_name'); ?></title>

    <link rel="stylesheet" href="<?php echo e(asset('public/css/invoice.css?v=' . version('short'))); ?>">

    <style type="text/css">
        * {
            font-family: DejaVu Sans;
        }
    </style>

    <?php echo $__env->yieldPushContent('css'); ?>

    <?php echo $__env->yieldPushContent('stylesheet'); ?>

    <?php echo $__env->yieldPushContent('js'); ?>

    <?php echo $__env->yieldPushContent('scripts'); ?>

    <?php echo $__env->yieldPushContent('head_end'); ?>
</head>
