<?php $__env->startSection('title', trans_choice('general.transactions', 2)); ?>

<?php $__env->startSection('content'); ?>
<!-- Default box -->
<div class="box box-success">
    <div class="box-header with-border">
        <?php echo Form::open(['url' => 'banking/transactions', 'role' => 'form', 'method' => 'GET']); ?>

        <div id="items" class="pull-left box-filter">
            <span class="title-filter hidden-xs"><?php echo e(trans('general.search')); ?>:</span>
            <?php echo Form::dateRange('date', trans('general.date'), 'calendar', []); ?>

            <?php echo Form::select('accounts[]', $accounts, request('accounts'), ['id' => 'filter-accounts', 'class' => 'form-control input-filter input-lg', 'multiple' => 'multiple']); ?>

            <?php echo Form::select('type', $types, request('type'), ['class' => 'form-control input-filter input-sm']); ?>

            <?php echo Form::select('categories[]', $categories, request('categories'), ['id' => 'filter-categories', 'class' => 'form-control input-filter input-lg', 'multiple' => 'multiple']); ?>

            <?php echo Form::button('<span class="fa fa-filter"></span> &nbsp;' . trans('general.filter'), ['type' => 'submit', 'class' => 'btn btn-sm btn-default btn-filter']); ?>

        </div>
        <div class="pull-right">
            <span class="title-filter hidden-xs"><?php echo e(trans('general.show')); ?>:</span>
            <?php echo Form::select('limit', $limits, request('limit', setting('general.list_limit', '25')), ['class' => 'form-control input-filter input-sm', 'onchange' => 'this.form.submit()']); ?>

        </div>
        <?php echo Form::close(); ?>

    </div>
    <!-- /.box-header -->

    <div class="box-body">
        <div class="table table-responsive">
            <table class="table table-striped table-hover" id="tbl-transactions">
                <thead>
                    <tr>
                        <th class="col-md-2"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('paid_at', trans('general.date')));?></th>
                        <th class="col-md-2"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('account_name', trans('accounts.account_name')));?></th>
                        <th class="col-md-2"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('type', trans_choice('general.types', 1)));?></th>
                        <th class="col-md-2"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('category_name', trans_choice('general.categories', 1)));?></th>
                        <th class="col-md-2"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('description', trans('general.description')));?></th>
                        <th class="col-md-2 text-right amount-space"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('amount', trans('general.amount')));?></th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(Date::parse($item->paid_at)->format($date_format)); ?></td>
                        <td><?php echo e($item->account_name); ?></td>
                        <td><?php echo e($item->type); ?></td>
                        <td><?php echo e($item->category_name); ?></td>
                        <td><?php echo e($item->description); ?></td>
                        <td class="text-right amount-space"><?php echo money($item->amount, $item->currency_code, true); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <!-- /.box-body -->

    <div class="box-footer">
    </div>
    <!-- /.box-footer -->
</div>
<!-- /.box -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('vendor/almasaeed2010/adminlte/plugins/daterangepicker/moment.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/almasaeed2010/adminlte/plugins/daterangepicker/daterangepicker.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/almasaeed2010/adminlte/plugins/datepicker/bootstrap-datepicker.js')); ?>"></script>
<?php if(language()->getShortCode() != 'en'): ?>
<script src="<?php echo e(asset('vendor/almasaeed2010/adminlte/plugins/datepicker/locales/bootstrap-datepicker.' . language()->getShortCode() . '.js')); ?>"></script>
<?php endif; ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('vendor/almasaeed2010/adminlte/plugins/daterangepicker/daterangepicker.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('vendor/almasaeed2010/adminlte/plugins/datepicker/datepicker3.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    $(document).ready(function(){
        $("#filter-accounts").select2({
            placeholder: "<?php echo e(trans('general.form.select.field', ['field' => trans_choice('general.accounts', 1)])); ?>"
        });

        $("#filter-categories").select2({
            placeholder: "<?php echo e(trans('general.form.select.field', ['field' => trans_choice('general.categories', 1)])); ?>"
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>