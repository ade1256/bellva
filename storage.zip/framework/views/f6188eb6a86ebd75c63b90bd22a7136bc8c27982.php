<?php echo $__env->yieldPushContent('content_start'); ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper no-margin">
    <?php echo $__env->yieldPushContent('content_wrapper_start'); ?>

    <!-- Content Header (Page header) -->
    <section class="content-header content-center">
        <?php echo $__env->yieldPushContent('content_header_start'); ?>

        <h1>
            <?php echo $__env->yieldContent('title'); ?>
            <?php echo $__env->yieldContent('new_button'); ?>
        </h1>

        <?php echo $__env->yieldPushContent('content_header_end'); ?>
    </section>

    <!-- Main content -->
    <section class="content content-center">
        <?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php echo $__env->yieldPushContent('content_content_start'); ?>

        <?php echo $__env->yieldContent('content'); ?>

        <?php echo $__env->yieldPushContent('content_content_end'); ?>
    </section>
    <!-- /.content -->

    <?php echo $__env->yieldPushContent('content_wrapper_end'); ?>
</div>
<!-- /.content-wrapper -->

<script type="text/javascript">
    $('div.alert').not('.alert-important').delay(3000).fadeOut(350);
</script>

<?php echo $__env->yieldPushContent('content_end'); ?>