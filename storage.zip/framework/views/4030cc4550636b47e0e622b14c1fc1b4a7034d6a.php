<?php $__env->startSection('title', trans('general.title.new', ['type' => trans_choice('general.payments', 1)])); ?>

<?php $__env->startSection('content'); ?>
    <!-- Default box -->
    <div class="box box-success">
        <?php echo Form::open(['url' => 'expenses/payments', 'files' => true, 'role' => 'form', 'class' => 'form-loading-button']); ?>


        <div class="box-body">
            <?php echo e(Form::textGroup('paid_at', trans('general.date'), 'calendar',['id' => 'paid_at', 'class' => 'form-control', 'required' => 'required', 'data-inputmask' => '\'alias\': \'yyyy-mm-dd\'', 'data-mask' => '', 'autocomplete' => 'off'], Date::now()->toDateString())); ?>


            <?php echo Form::hidden('currency_code', $account_currency_code, ['id' => 'currency_code', 'class' => 'form-control', 'required' => 'required']); ?>

            <?php echo Form::hidden('currency_rate', '', ['id' => 'currency_rate']); ?>


            <?php echo e(Form::textGroup('amount', trans('general.amount'), 'money', ['required' => 'required', 'autofocus' => 'autofocus'])); ?>


            <?php echo $__env->yieldPushContent('account_id_input_start'); ?>
            <div class="form-group col-md-6 form-small">
                <?php echo Form::label('account_id', trans_choice('general.accounts', 1), ['class' => 'control-label']); ?>

                <div class="input-group">
                    <div class="input-group-addon"><i class="fa fa-university"></i></div>
                    <?php echo Form::select('account_id', $accounts, setting('general.default_account'), array_merge(['class' => 'form-control', 'placeholder' => trans('general.form.select.field', ['field' => trans_choice('general.accounts', 1)])])); ?>

                    <div class="input-group-append">
                        <?php echo Form::text('currency', $account_currency_code, ['id' => 'currency', 'class' => 'form-control', 'required' => 'required', 'disabled' => 'disabled']); ?>

                    </div>
                </div>
            </div>
            <?php echo $__env->yieldPushContent('account_id_input_end'); ?>

            <?php echo $__env->yieldPushContent('vendor_id_input_start'); ?>
            <div class="form-group col-md-6">
                <?php echo Form::label('vendor_id', trans_choice('general.vendors', 1), ['class' => 'control-label']); ?>

                <div class="input-group">
                    <div class="input-group-addon"><i class="fa fa-user"></i></div>
                    <?php echo Form::select('vendor_id', $vendors, null, array_merge(['id' => 'vendor_id', 'class' => 'form-control', 'placeholder' => trans('general.form.select.field', ['field' => trans_choice('general.vendors', 1)])])); ?>

                    <span class="input-group-btn">
                    <button type="button" id="button-vendor" class="btn btn-default btn-icon"><i class="fa fa-plus"></i></button>
                </span>
                </div>
            </div>
            <?php echo $__env->yieldPushContent('vendor_id_input_end'); ?>

            <?php echo e(Form::textareaGroup('description', trans('general.description'))); ?>


            <?php echo $__env->yieldPushContent('category_id_input_start'); ?>
            <div class="form-group col-md-6 required <?php echo e($errors->has('category_id') ? 'has-error' : ''); ?>">
                <?php echo Form::label('category_id', trans_choice('general.categories', 1), ['class' => 'control-label']); ?>

                <div class="input-group">
                    <div class="input-group-addon"><i class="fa fa-folder-open-o"></i></div>
                    <?php echo Form::select('category_id', $categories, null, array_merge(['class' => 'form-control', 'placeholder' => trans('general.form.select.field', ['field' => trans_choice('general.categories', 1)])])); ?>

                    <div class="input-group-btn">
                        <button type="button" id="button-category" class="btn btn-default btn-icon"><i class="fa fa-plus"></i></button>
                    </div>
                </div>
                <?php echo $errors->first('category_id', '<p class="help-block">:message</p>'); ?>

            </div>
            <?php echo $__env->yieldPushContent('category_id_input_end'); ?>

            <?php echo e(Form::recurring('create')); ?>


            <?php echo e(Form::selectGroup('payment_method', trans_choice('general.payment_methods', 1), 'credit-card', $payment_methods, setting('general.default_payment_method'))); ?>


            <?php echo e(Form::textGroup('reference', trans('general.reference'), 'file-text-o',[])); ?>


            <?php echo e(Form::fileGroup('attachment', trans('general.attachment'))); ?>

        </div>
        <!-- /.box-body -->

        <div class="box-footer">
            <?php echo e(Form::saveButtons('expenses/payments')); ?>

        </div>
        <!-- /.box-footer -->

        <?php echo Form::close(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('vendor/almasaeed2010/adminlte/plugins/datepicker/bootstrap-datepicker.js')); ?>"></script>
    <?php if(language()->getShortCode() != 'en'): ?>
    <script src="<?php echo e(asset('vendor/almasaeed2010/adminlte/plugins/datepicker/locales/bootstrap-datepicker.' . language()->getShortCode() . '.js')); ?>"></script>
    <?php endif; ?>
    <script src="<?php echo e(asset('public/js/bootstrap-fancyfile.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/almasaeed2010/adminlte/plugins/colorpicker/bootstrap-colorpicker.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('vendor/almasaeed2010/adminlte/plugins/datepicker/datepicker3.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/css/bootstrap-fancyfile.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/almasaeed2010/adminlte/plugins/colorpicker/bootstrap-colorpicker.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript">
        $(document).ready(function(){
            $("#amount").maskMoney({
                thousands : '<?php echo e($currency->thousands_separator); ?>',
                decimal : '<?php echo e($currency->decimal_mark); ?>',
                precision : <?php echo e($currency->precision); ?>,
                allowZero : true,
                <?php if($currency->symbol_first): ?>
                prefix : '<?php echo e($currency->symbol); ?>'
                <?php else: ?>
                suffix : '<?php echo e($currency->symbol); ?>'
                <?php endif; ?>
            });

            $('#amount').trigger('focus');

            $('#account_id').trigger('change');

            //Date picker
            $('#paid_at').datepicker({
                format: 'yyyy-mm-dd',
                todayBtn: 'linked',
                weekStart: 1,
                autoclose: true,
                language: '<?php echo e(language()->getShortCode()); ?>'
            });

            $("#account_id").select2({
                placeholder: "<?php echo e(trans('general.form.select.field', ['field' => trans_choice('general.accounts', 1)])); ?>"
            });

            $("#category_id").select2({
                placeholder: "<?php echo e(trans('general.form.select.field', ['field' => trans_choice('general.categories', 1)])); ?>"
            });

            $("#vendor_id").select2({
                placeholder: {
                    id: '-1', // the value of the option
                    text: "<?php echo e(trans('general.form.select.field', ['field' => trans_choice('general.vendors', 1)])); ?>"
                }
            });

            $("#payment_method").select2({
                placeholder: "<?php echo e(trans('general.form.select.field', ['field' => trans_choice('general.payment_methods', 1)])); ?>"
            });

            $('#attachment').fancyfile({
                text  : '<?php echo e(trans('general.form.select.file')); ?>',
                style : 'btn-default',
                placeholder : '<?php echo e(trans('general.form.no_file_selected')); ?>'
            });
        });

        $(document).on('change', '#account_id', function (e) {
            $.ajax({
                url: '<?php echo e(url("banking/accounts/currency")); ?>',
                type: 'GET',
                dataType: 'JSON',
                data: 'account_id=' + $(this).val(),
                success: function(data) {
                    $('#currency').val(data.currency_code);

                    $('#currency_code').val(data.currency_code);
                    $('#currency_rate').val(data.currency_rate);

                    amount = $('#amount').maskMoney('unmasked')[0];

                    $("#amount").maskMoney({
                        thousands : data.thousands_separator,
                        decimal : data.decimal_mark,
                        precision : data.precision,
                        allowZero : true,
                        prefix : (data.symbol_first) ? data.symbol : '',
                        suffix : (data.symbol_first) ? '' : data.symbol
                    });

                    $('#amount').val(amount);

                    $('#amount').trigger('focus');
                }
            });
        });

        $(document).on('click', '#button-vendor', function (e) {
            $('#modal-create-vendor').remove();

            $.ajax({
                url: '<?php echo e(url("modals/vendors/create")); ?>',
                type: 'GET',
                dataType: 'JSON',
                success: function(json) {
                    if (json['success']) {
                        $('body').append(json['html']);
                    }
                }
            });
        });

        $(document).on('click', '#button-category', function (e) {
            $('#modal-create-category').remove();

            $.ajax({
                url: '<?php echo e(url("modals/categories/create")); ?>',
                type: 'GET',
                dataType: 'JSON',
                data: {type: 'expense'},
                success: function(json) {
                    if (json['success']) {
                        $('body').append(json['html']);
                    }
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>