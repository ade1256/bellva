<?php $__env->startSection('title', trans_choice('general.invoices', 1) . ': ' . $invoice->invoice_number); ?>

<?php $__env->startSection('content'); ?>
<div class="row header">
    <div class="col-58">
        <?php if($logo): ?>
        <img src="<?php echo e($logo); ?>" class="logo" />
        <?php endif; ?>
    </div>
    <div class="col-42">
        <div class="text company">
            <strong><?php echo e(setting('general.company_name')); ?></strong><br>
            <?php echo nl2br(setting('general.company_address')); ?><br>
            <?php if(setting('general.company_tax_number')): ?>
                <?php echo e(trans('general.tax_number')); ?>: <?php echo e(setting('general.company_tax_number')); ?><br>
            <?php endif; ?>
            <br>
            <?php if(setting('general.company_phone')): ?>
                <?php echo e(setting('general.company_phone')); ?><br>
            <?php endif; ?>
            <?php echo e(setting('general.company_email')); ?>

        </div>
    </div>
</div>

<div class="row">
    <div class="col-58">
        <div class="text">
            <?php echo e(trans('invoices.bill_to')); ?><br><br>
            <?php echo $__env->yieldPushContent('name_input_start'); ?>
            <strong><?php echo e($invoice->customer_name); ?></strong><br>
            <?php echo $__env->yieldPushContent('name_input_end'); ?>
            <?php echo $__env->yieldPushContent('address_input_start'); ?>
            <?php echo nl2br($invoice->customer_address); ?><br>
            <?php echo $__env->yieldPushContent('address_input_end'); ?>
            <?php echo $__env->yieldPushContent('tax_number_input_start'); ?>
            <?php if($invoice->customer_tax_number): ?>
                <?php echo e(trans('general.tax_number')); ?>: <?php echo e($invoice->customer_tax_number); ?><br>
            <?php endif; ?>
            <?php echo $__env->yieldPushContent('tax_number_input_end'); ?>
            <br>
            <?php echo $__env->yieldPushContent('phone_input_start'); ?>
            <?php if($invoice->customer_phone): ?>
                <?php echo e($invoice->customer_phone); ?><br>
            <?php endif; ?>
            <?php echo $__env->yieldPushContent('phone_input_end'); ?>
            <?php echo $__env->yieldPushContent('email_start'); ?>
            <?php echo e($invoice->customer_email); ?>

            <?php echo $__env->yieldPushContent('email_input_end'); ?>
        </div>
    </div>
    <div class="col-42">
        <div class="text">
            <table>
                <tbody>
                    <?php echo $__env->yieldPushContent('invoice_number_input_start'); ?>
                    <tr>
                        <th><?php echo e(trans('invoices.invoice_number')); ?>:</th>
                        <td class="text-right"><?php echo e($invoice->invoice_number); ?></td>
                    </tr>
                    <?php echo $__env->yieldPushContent('invoice_number_input_end'); ?>
                    <?php echo $__env->yieldPushContent('order_number_input_start'); ?>
                    <?php if($invoice->order_number): ?>
                    <tr>
                        <th><?php echo e(trans('invoices.order_number')); ?>:</th>
                        <td class="text-right"><?php echo e($invoice->order_number); ?></td>
                    </tr>
                    <?php endif; ?>
                    <?php echo $__env->yieldPushContent('order_number_input_end'); ?>
                    <?php echo $__env->yieldPushContent('invoiced_at_input_start'); ?>
                    <tr>
                        <th><?php echo e(trans('invoices.invoice_date')); ?>:</th>
                        <td class="text-right"><?php echo e(Date::parse($invoice->invoiced_at)->format($date_format)); ?></td>
                    </tr>
                    <?php echo $__env->yieldPushContent('invoiced_at_input_end'); ?>
                    <?php echo $__env->yieldPushContent('due_at_input_start'); ?>
                    <tr>
                        <th><?php echo e(trans('invoices.payment_due')); ?>:</th>
                        <td class="text-right"><?php echo e(Date::parse($invoice->due_at)->format($date_format)); ?></td>
                    </tr>
                    <?php echo $__env->yieldPushContent('due_at_input_end'); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<table class="lines">
    <thead>
        <tr>
            <?php echo $__env->yieldPushContent('actions_th_start'); ?>
            <?php echo $__env->yieldPushContent('actions_th_end'); ?>
            <?php echo $__env->yieldPushContent('name_th_start'); ?>
            <th class="item"><?php echo e(trans_choice($text_override['items'], 2)); ?></th>
            <?php echo $__env->yieldPushContent('name_th_end'); ?>
            <?php echo $__env->yieldPushContent('quantity_th_start'); ?>
            <th class="quantity"><?php echo e(trans($text_override['quantity'])); ?></th>
            <?php echo $__env->yieldPushContent('quantity_th_end'); ?>
            <?php echo $__env->yieldPushContent('price_th_start'); ?>
            <th class="price"><?php echo e(trans($text_override['price'])); ?></th>
            <?php echo $__env->yieldPushContent('price_th_end'); ?>
            <?php echo $__env->yieldPushContent('taxes_th_start'); ?>
            <?php echo $__env->yieldPushContent('taxes_th_end'); ?>
            <?php echo $__env->yieldPushContent('total_th_start'); ?>
            <th class="total"><?php echo e(trans('invoices.total')); ?></th>
            <?php echo $__env->yieldPushContent('total_th_end'); ?>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $invoice->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <?php echo $__env->yieldPushContent('actions_td_start'); ?>
            <?php echo $__env->yieldPushContent('actions_td_end'); ?>
            <?php echo $__env->yieldPushContent('name_td_start'); ?>
            <td class="item">
                <?php echo e($item->name); ?>

                <?php if($item->sku): ?>
                    <br><small><?php echo e(trans('items.sku')); ?>: <?php echo e($item->sku); ?></small>
                <?php endif; ?>
            </td>
            <?php echo $__env->yieldPushContent('name_td_end'); ?>
            <?php echo $__env->yieldPushContent('quantity_td_start'); ?>
            <td class="quantity"><?php echo e($item->quantity); ?></td>
            <?php echo $__env->yieldPushContent('quantity_td_end'); ?>
            <?php echo $__env->yieldPushContent('price_td_start'); ?>
            <td class="style-price price"><?php echo money($item->price, $invoice->currency_code, true); ?></td>
            <?php echo $__env->yieldPushContent('price_td_end'); ?>
            <?php echo $__env->yieldPushContent('taxes_td_start'); ?>
            <?php echo $__env->yieldPushContent('taxes_td_end'); ?>
            <?php echo $__env->yieldPushContent('total_td_start'); ?>
            <td class="style-price total"><?php echo money($item->total, $invoice->currency_code, true); ?></td>
            <?php echo $__env->yieldPushContent('total_td_end'); ?>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<div class="row">
    <div class="col-58">
        <?php echo $__env->yieldPushContent('notes_input_start'); ?>
        <?php if($invoice->notes): ?>
        <table class="text" style="page-break-inside: avoid;">
            <tr><th><?php echo e(trans_choice('general.notes', 2)); ?></th></tr>
            <tr><td><?php echo e($invoice->notes); ?></td></tr>
        </table>
        <?php endif; ?>
        <?php echo $__env->yieldPushContent('notes_input_end'); ?>
    </div>
    <div class="col-42">
        <table class="text" style="page-break-inside: avoid;">
            <tbody>
            <?php $__currentLoopData = $invoice->totals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $total): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($total->code != 'total'): ?>
                    <?php echo $__env->yieldPushContent($total->code . '_td_start'); ?>
                    <tr>
                        <th><?php echo e(trans($total->title)); ?>:</th>
                        <td class="style-price text-right"><?php echo money($total->amount, $invoice->currency_code, true); ?></td>
                    </tr>
                    <?php echo $__env->yieldPushContent($total->code . '_td_end'); ?>
                <?php else: ?>
                    <?php if($invoice->paid): ?>
                        <tr class="text-success">
                            <th><?php echo e(trans('invoices.paid')); ?>:</th>
                            <td class="style-price text-right">- <?php echo money($invoice->paid, $invoice->currency_code, true); ?></td>
                        </tr>
                    <?php endif; ?>
                    <?php echo $__env->yieldPushContent('grand_total_td_start'); ?>
                    <tr>
                        <th><?php echo e(trans($total->name)); ?>:</th>
                        <td class="style-price text-right"><?php echo money($total->amount - $invoice->paid, $invoice->currency_code, true); ?></td>
                    </tr>
                    <?php echo $__env->yieldPushContent('grand_total_td_end'); ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php if(isset($currency_style) && $currency_style): ?>
<?php $__env->startPush('stylesheet'); ?>
<style type="text/css">
    .style-price {
        font-family: sans-serif;
        font-size: 15px;
    }
</style>
<?php $__env->stopPush(); ?>
<?php endif; ?>
<?php echo $__env->make('layouts.invoice', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>