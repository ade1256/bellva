<?php echo $__env->yieldPushContent($name . '_input_start'); ?>

<div class="form-group <?php echo e($col); ?> <?php echo e(isset($attributes['required']) ? 'required' : ''); ?> <?php echo e($errors->has($name) ? 'has-error' : ''); ?>">
    <?php echo Form::label($name, $text, ['class' => 'control-label']); ?>

    <div class="input-group">
        <div class="input-group-addon"><i class="fa fa-<?php echo e($icon); ?>"></i></div>
        <?php echo Form::text($name, $value, array_merge(['class' => 'form-control', 'placeholder' => trans('general.form.enter', ['field' => $text])], $attributes)); ?>

    </div>
    <?php echo $errors->first($name, '<p class="help-block">:message</p>'); ?>

</div>

<?php echo $__env->yieldPushContent($name . '_input_end'); ?>
