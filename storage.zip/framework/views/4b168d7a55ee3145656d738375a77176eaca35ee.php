<?php $__env->startSection('title', trans_choice('general.categories', 2)); ?>

<?php if (app('laratrust')->can('create-settings-categories')) : ?>
<?php $__env->startSection('new_button'); ?>
<span class="new-button"><a href="<?php echo e(url('settings/categories/create')); ?>" class="btn btn-success btn-sm"><span class="fa fa-plus"></span> &nbsp;<?php echo e(trans('general.add_new')); ?></a></span>
<?php $__env->stopSection(); ?>
<?php endif; // app('laratrust')->can ?>

<?php $__env->startSection('content'); ?>
<!-- Default box -->
<div class="box box-success">
    <div class="box-header with-border">
        <?php echo Form::open(['url' => 'settings/categories', 'role' => 'form', 'method' => 'GET']); ?>

        <div id="items" class="pull-left box-filter">
            <span class="title-filter hidden-xs"><?php echo e(trans('general.search')); ?>:</span>
            <?php echo Form::text('search', request('search'), ['class' => 'form-control input-filter input-sm', 'placeholder' => trans('general.search_placeholder')]); ?>

            <?php echo Form::select('types[]', $types, request('types'), ['id' => 'filter-types', 'class' => 'form-control input-filter input-lg', 'multiple' => 'multiple']); ?>

            <?php echo Form::button('<span class="fa fa-filter"></span> &nbsp;' . trans('general.filter'), ['type' => 'submit', 'class' => 'btn btn-sm btn-default btn-filter']); ?>

        </div>
        <div class="pull-right">
            <span class="title-filter hidden-xs"><?php echo e(trans('general.show')); ?>:</span>
            <?php echo Form::select('limit', $limits, request('limit', setting('general.list_limit', '25')), ['class' => 'form-control input-filter input-sm', 'onchange' => 'this.form.submit()']); ?>

        </div>
        <?php echo Form::close(); ?>

    </div>
    <!-- /.box-header -->

    <div class="box-body">
        <div class="table table-responsive">
            <table class="table table-striped table-hover" id="tbl-categories">
                <thead>
                    <tr>
                        <th class="col-md-5"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('name', trans('general.name')));?></th>
                        <th class="col-md-3"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('type', trans_choice('general.types', 1)));?></th>
                        <th class="col-md-2 hidden-xs"><?php echo e(trans('general.color')); ?></th>
                        <th class="col-md-1 hidden-xs"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('enabled', trans_choice('general.statuses', 1)));?></th>
                        <th class="col-md-1 text-center"><?php echo e(trans('general.actions')); ?></th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                        <?php if(($item->type == 'income') && $auth_user->can('read-reports-income-summary')): ?>
                        <a href="<?php echo e(url('reports/income-summary?categories[]=' . $item->id)); ?>"><?php echo e($item->name); ?></a>
                        <?php elseif(($item->type == 'expense') && $auth_user->can('read-reports-expense-summary')): ?>
                        <a href="<?php echo e(url('reports/expense-summary?categories[]=' . $item->id)); ?>"><?php echo e($item->name); ?></a>
                        <?php elseif(($item->type == 'item') && $auth_user->can('read-common-items')): ?>
                        <a href="<?php echo e(url('common/items?categories[]=' . $item->id)); ?>"><?php echo e($item->name); ?></a>
                        <?php else: ?>
                        <a href="<?php echo e(url('settings/categories/' . $item->id . '/edit')); ?>"><?php echo e($item->name); ?></a>
                        <?php endif; ?>
                        </td>
                        <td><?php echo e($types[$item->type]); ?></td>
                        <td class="hidden-xs"><i class="fa fa-2x fa-circle" style="color:<?php echo e($item->color); ?>;"></i></td>
                        <td class="hidden-xs">
                            <?php if($item->enabled): ?>
                                <span class="label label-success"><?php echo e(trans('general.enabled')); ?></span>
                            <?php else: ?>
                                <span class="label label-danger"><?php echo e(trans('general.disabled')); ?></span>
                            <?php endif; ?>
                        </td>
                        <td class="text-center">
                            <div class="btn-group">
                                <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" data-toggle-position="left" aria-expanded="false">
                                    <i class="fa fa-ellipsis-h"></i>
                                </button>
                                <ul class="dropdown-menu dropdown-menu-right">
                                    <li><a href="<?php echo e(url('settings/categories/' . $item->id . '/edit')); ?>"><?php echo e(trans('general.edit')); ?></a></li>
                                    <?php if($item->enabled): ?>
                                    <li><a href="<?php echo e(route('categories.disable', $item->id)); ?>"><?php echo e(trans('general.disable')); ?></a></li>
                                    <?php else: ?>
                                    <li><a href="<?php echo e(route('categories.enable', $item->id)); ?>"><?php echo e(trans('general.enable')); ?></a></li>
                                    <?php endif; ?>
                                    <?php if($item->id != $transfer_id): ?>
                                    <?php if (app('laratrust')->can('delete-settings-categories')) : ?>
                                    <li class="divider"></li>
                                    <li><?php echo Form::deleteLink($item, 'settings/categories'); ?></li>
                                    <?php endif; // app('laratrust')->can ?>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <!-- /.box-body -->

    <div class="box-footer">
        <?php echo $__env->make('partials.admin.pagination', ['items' => $categories, 'type' => 'categories'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <!-- /.box-footer -->
</div>
<!-- /.box -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    $(document).ready(function(){
        $("#filter-types").select2({
            placeholder: "<?php echo e(trans('general.form.select.field', ['field' => trans_choice('general.types', 1)])); ?>"
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>