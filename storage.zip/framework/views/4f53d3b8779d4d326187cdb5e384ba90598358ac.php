<?php $__env->startSection('title', trans_choice('general.updates', 2)); ?>

<?php $__env->startSection('new_button'); ?>
<span class="new-button"><a href="<?php echo e(url('install/updates/check')); ?>" class="btn btn-warning btn-sm"><span class="fa fa-history"></span> &nbsp;<?php echo e(trans('updates.check')); ?></a></span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<!-- Default box -->
<div class="box box-success">
    <div class="box-header with-border">
        <i class="fa fa-rocket"></i>
        <h3 class="box-title"><?php echo e(trans_choice('general.modules', 2)); ?></h3>
    </div>
    <!-- /.box-header -->

    <div class="box-body">
        <div class="table table-responsive">
            <table class="table table-striped table-hover" id="tbl-translations">
                <thead>
                    <tr>
                        <th class="col-md-4"><?php echo e(trans('general.name')); ?></th>
                        <th class="col-md-2"><?php echo e(trans_choice('general.categories', 1)); ?></th>
                        <th class="col-md-2"><?php echo e(trans('updates.installed_version')); ?></th>
                        <th class="col-md-2"><?php echo e(trans('updates.latest_version')); ?></th>
                        <th class="col-md-2"><?php echo e(trans('general.actions')); ?></th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($module->name); ?></td>
                        <td><?php echo e($module->category); ?></td>
                        <td><?php echo e($module->installed); ?></td>
                        <td><?php echo e($module->latest); ?></td>
                        <td>
                            <a href="<?php echo e(url('install/updates/update/' . $module->alias . '/' . $module->latest)); ?>" class="btn btn-warning btn-xs"><i class="fa fa-refresh" aria-hidden="true"></i> <?php echo e(trans_choice('general.updates', 1)); ?></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <!-- /.box-body -->

</div>
<!-- /.box -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>