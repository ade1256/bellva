<div class="box-body">
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th class="col-sm-2">&nbsp;</th>
                    <?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th class="col-sm-2 text-right"><?php echo e(trans('reports.quarter.' . $date)); ?></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <th class="col-sm-2 text-right"><?php echo e(trans_choice('general.totals', 1)); ?></th>
                </tr>
            </thead>
        </table>
        <table class="table table-hover" style="margin-top: 40px">
            <thead>
                <tr>
                    <th class="col-sm-2" colspan="6"><?php echo e(trans_choice('general.incomes', 1)); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $compares['income']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category_id => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="col-sm-2"><?php echo e($income_categories[$category_id]); ?></td>
                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php  $gross['income'][$i] += $item['amount'];  ?>
                            <td class="col-sm-2 text-right"><?php echo money($item['amount'], setting('general.default_currency'), true); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
                <tr>
                    <th class="col-sm-2"><?php echo e(trans('reports.gross_profit')); ?></th>
                    <?php $__currentLoopData = $gross['income']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th class="col-sm-2 text-right"><?php echo money($item, setting('general.default_currency'), true); ?></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            </tfoot>
        </table>
        <table class="table table-hover" style="margin-top: 40px">
            <thead>
                <tr>
                    <th class="col-sm-2" colspan="6"><?php echo e(trans_choice('general.expenses', 2)); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $compares['expense']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category_id => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="col-sm-2"><?php echo e($expense_categories[$category_id]); ?></td>
                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php  $gross['expense'][$i] += $item['amount'];  ?>
                            <td class="col-sm-2 text-right"><?php echo money($item['amount'], setting('general.default_currency'), true); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
                <tr>
                    <th class="col-sm-2"><?php echo e(trans('reports.total_expenses')); ?></th>
                    <?php $__currentLoopData = $gross['expense']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th class="col-sm-2 text-right"><?php echo money($item, setting('general.default_currency'), true); ?></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            </tfoot>
        </table>
        <table class="table" style="margin-top: 40px">
            <tbody>
                <tr>
                    <th class="col-sm-2" colspan="6"><?php echo e(trans('reports.net_profit')); ?></th>
                    <?php $__currentLoopData = $totals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $total): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th class="col-sm-2 text-right"><span><?php echo money($total['amount'], $total['currency_code'], true); ?></span></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            </tbody>
        </table>
    </div>
</div>
