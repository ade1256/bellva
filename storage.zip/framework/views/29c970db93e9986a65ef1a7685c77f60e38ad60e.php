<?php $__env->startSection('title', trans('reports.summary.income')); ?>

<?php $__env->startSection('new_button'); ?>
<span class="new-button"><a href="<?php echo e(url($print_url)); ?>" target="_blank" class="btn btn-success btn-sm"><span class="fa fa-print"></span> &nbsp;<?php echo e(trans('general.print')); ?></a></span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Default box -->
<div class="box box-success">
    <div class="box-header with-border">
        <?php echo Form::open(['url' => 'reports/income-summary', 'role' => 'form', 'method' => 'GET']); ?>

        <div id="items" class="pull-left box-filter">
            <?php echo Form::select('year', $years, request('year', $this_year), ['class' => 'form-control input-filter input-sm']); ?>

            <?php echo Form::select('status', $statuses, request('status'), ['class' => 'form-control input-filter input-sm']); ?>

            <?php echo Form::select('accounts[]', $accounts, request('accounts'), ['id' => 'filter-accounts', 'class' => 'form-control input-filter input-lg', 'multiple' => 'multiple']); ?>

            <?php echo Form::select('customers[]', $customers, request('customers'), ['id' => 'filter-customers', 'class' => 'form-control input-filter input-lg', 'multiple' => 'multiple']); ?>

            <?php echo Form::select('categories[]', $categories, request('categories'), ['id' => 'filter-categories', 'class' => 'form-control input-filter input-lg', 'multiple' => 'multiple']); ?>

            <?php echo Form::button('<span class="fa fa-filter"></span> &nbsp;' . trans('general.filter'), ['type' => 'submit', 'class' => 'btn btn-sm btn-default btn-filter']); ?>

        </div>
        <?php echo Form::close(); ?>

    </div>

    <?php echo $__env->make('reports.income_summary.body', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<!-- /.box -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    $(document).ready(function(){
        $("#filter-accounts").select2({
            placeholder: "<?php echo e(trans('general.form.select.field', ['field' => trans_choice('general.accounts', 1)])); ?>"
        });

        $("#filter-customers").select2({
            placeholder: "<?php echo e(trans('general.form.select.field', ['field' => trans_choice('general.customers', 1)])); ?>"
        });

        $("#filter-categories").select2({
            placeholder: "<?php echo e(trans('general.form.select.field', ['field' => trans_choice('general.categories', 1)])); ?>"
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>