<html lang="<?php echo e(env('APP_LOCALE')); ?>">
    <?php echo $__env->make('partials.auth.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <body class="hold-transition login-page">
        <?php echo $__env->yieldPushContent('body_start'); ?>

        <div class="login-box">
            <?php echo $__env->yieldPushContent('login_box_start'); ?>

            <div class="login-logo">
                <img src="<?php echo e(asset('public/img/logo-bellva-white.png')); ?>" alt="Bellva" />
            </div>
            <!-- /.login-logo -->

            <div class="login-box-body">
                <p class="login-box-msg"><?php echo $__env->yieldContent('message'); ?></p>

                <?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <?php echo $__env->yieldPushContent('login_content_start'); ?>

                <?php echo $__env->yieldContent('content'); ?>

                <?php echo $__env->yieldPushContent('login_content_end'); ?>
            </div>
            <!-- /.login-box-body -->

            <div class="login-box-footer">
                <?php echo e(trans('footer.powered')); ?>: <a href="<?php echo e(trans('footer.link')); ?>" target="_blank"><?php echo e(trans('footer.software')); ?></a>
            </div>
            <!-- /.login-box-footer -->

            <?php echo $__env->yieldPushContent('login_box_end'); ?>
        </div>

        <?php echo $__env->yieldPushContent('body_end'); ?>
    </body>
</html>
