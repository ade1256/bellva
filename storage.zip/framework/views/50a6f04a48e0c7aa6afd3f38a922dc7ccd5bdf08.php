<?php $__env->startSection('title', trans_choice('general.invoices', 1) . ': ' . $invoice->invoice_number); ?>

<?php $__env->startSection('content'); ?>
    <?php if(($recurring = $invoice->recurring) && ($next = $recurring->next())): ?>
        <div class="callout callout-info">
            <h4><?php echo e(trans('recurring.recurring')); ?></h4>

            <p><?php echo e(trans('recurring.message', [
                    'type' => mb_strtolower(trans_choice('general.invoices', 1)),
                    'date' => $next->format($date_format)
                ])); ?>

            </p>
        </div>
    <?php endif; ?>

    <?php if($invoice->status->code == 'draft'): ?>
    <div class="callout callout-warning">
        <p><?php echo trans('invoices.messages.draft'); ?></p>
    </div>
    <?php endif; ?>

    <?php if($invoice->status->code != 'paid'): ?>
    <div class="row show-invoice">
        <div class="col-md-12 no-padding-right">
            <ul class="timeline">
                <li>
                    <i class="fa fa-plus bg-blue"></i>

                    <div class="timeline-item">
                        <h3 class="timeline-header"><?php echo e(trans('general.title.create', ['type' => trans_choice('general.invoices', 1)])); ?></h3>

                        <div class="timeline-body">
                            <?php echo e(trans_choice('general.statuses', 1) . ': ' . trans('invoices.messages.status.created', ['date' => Date::parse($invoice->created_at)->format($date_format)])); ?>


                            <a href="<?php echo e(url('incomes/invoices/' . $invoice->id . '/edit')); ?>" class="btn btn-default btn-xs">
                                <?php echo e(trans('general.edit')); ?>

                            </a>
                        </div>
                    </div>
                </li>
                <li>
                    <i class="fa fa-envelope bg-orange"></i>

                    <div class="timeline-item">
                        <h3 class="timeline-header"><?php echo e(trans('general.title.send', ['type' => trans_choice('general.invoices', 1)])); ?></h3>

                        <div class="timeline-body">
                            <?php if($invoice->status->code != 'sent' && $invoice->status->code != 'partial'): ?>
                                <?php echo e(trans_choice('general.statuses', 1) . ': ' . trans('invoices.messages.status.send.draft')); ?>


                                <?php if (app('laratrust')->can('update-incomes-invoices')) : ?>
                                <?php if($invoice->invoice_status_code == 'draft'): ?>
                                    <a href="<?php echo e(url('incomes/invoices/' . $invoice->id . '/sent')); ?>" class="btn btn-default btn-xs"><?php echo e(trans('invoices.mark_sent')); ?></a>
                                <?php else: ?>
                                    <a href="javascript:void(0);" class="disabled btn btn-default btn-xs"><span class="text-disabled"> <?php echo e(trans('invoices.mark_sent')); ?></span></a>
                                <?php endif; ?>
                                <?php endif; // app('laratrust')->can ?>
                                <?php if($invoice->customer_email): ?>
                                    <a href="<?php echo e(url('incomes/invoices/' . $invoice->id . '/email')); ?>" class="btn btn-warning btn-xs"><?php echo e(trans('invoices.send_mail')); ?></a>
                                <?php else: ?>
                                    <a href="javascript:void(0);" class="btn btn-warning btn-xs green-tooltip disabled" data-toggle="tooltip" data-placement="right" title="<?php echo e(trans('invoices.messages.email_required')); ?>">
                                        <span class="text-disabled"><?php echo e(trans('invoices.send_mail')); ?></span>
                                    </a>
                                <?php endif; ?>
                            <?php else: ?>
                                <?php echo e(trans_choice('general.statuses', 1) . ': ' . trans('invoices.messages.status.send.sent', ['date' => Date::parse($invoice->created_at)->format($date_format)])); ?>

                            <?php endif; ?>
                        </div>
                    </div>
                </li>
                <li>
                    <i class="fa fa-money bg-green"></i>

                    <div class="timeline-item">
                        <h3 class="timeline-header"><?php echo e(trans('general.title.get', ['type' => trans('general.paid')])); ?></h3>

                        <div class="timeline-body">
                            <?php if($invoice->status->code != 'paid' && empty($invoice->payments()->count())): ?>
                                <?php echo e(trans_choice('general.statuses', 1) . ': ' . trans('invoices.messages.status.paid.await')); ?>

                            <?php else: ?>
                                <?php echo e(trans_choice('general.statuses', 1) . ': ' . trans('general.partially_paid')); ?>

                            <?php endif; ?>

                            <?php if (app('laratrust')->can('update-incomes-invoices')) : ?>
                            <a href="<?php echo e(url('incomes/invoices/' . $invoice->id . '/pay')); ?>" class="btn btn-default btn-xs"><?php echo e(trans('invoices.mark_paid')); ?></a>
                            <?php endif; // app('laratrust')->can ?>
                            <?php if(empty($invoice->payments()->count()) || (!empty($invoice->payments()->count()) && $invoice->paid != $invoice->amount)): ?>
                                <a href="#" id="button-payment" class="btn btn-success btn-xs"><?php echo e(trans('invoices.add_payment')); ?></a>
                            <?php endif; ?>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
    </div>
    <?php endif; ?>

    <div class="box box-success">
        <section class="invoice">
            <div id="badge">
                <div class="arrow-up"></div>
                <div class="label <?php echo e($invoice->status->label); ?>"><?php echo e(trans('invoices.status.' . $invoice->status->code)); ?></div>
                <div class="arrow-right"></div>
            </div>

            <div class="row invoice-header">
                <div class="col-xs-7">
                    <?php if(setting('general.invoice_logo')): ?>
                        <img src="<?php echo e(Storage::url(setting('general.invoice_logo'))); ?>" class="invoice-logo" />
                    <?php elseif(setting('general.company_logo')): ?>
                        <img src="<?php echo e(Storage::url(setting('general.company_logo'))); ?>" class="invoice-logo" />
                    <?php else: ?>
                        <img src="<?php echo e(asset('public/img/company.png')); ?>" class="invoice-logo" />
                    <?php endif; ?>
                </div>
                <div class="col-xs-5 invoice-company">
                    <address>
                        <strong><?php echo e(setting('general.company_name')); ?></strong><br>
                        <?php echo nl2br(setting('general.company_address')); ?><br>
                        <?php if(setting('general.company_tax_number')): ?>
                        <?php echo e(trans('general.tax_number')); ?>: <?php echo e(setting('general.company_tax_number')); ?><br>
                        <?php endif; ?>
                        <br>
                        <?php if(setting('general.company_phone')): ?>
                        <?php echo e(setting('general.company_phone')); ?><br>
                        <?php endif; ?>
                        <?php echo e(setting('general.company_email')); ?>

                    </address>
                </div>
            </div>

            <div class="row">
                <div class="col-xs-7">
                    <?php echo e(trans('invoices.bill_to')); ?>

                    <address>
                        <?php echo $__env->yieldPushContent('name_input_start'); ?>
                        <strong><?php echo e($invoice->customer_name); ?></strong><br>
                        <?php echo $__env->yieldPushContent('name_input_end'); ?>
                        <?php echo $__env->yieldPushContent('address_input_start'); ?>
                        <?php echo nl2br($invoice->customer_address); ?><br>
                        <?php echo $__env->yieldPushContent('address_input_end'); ?>
                        <?php echo $__env->yieldPushContent('tax_number_input_start'); ?>
                        <?php if($invoice->customer_tax_number): ?>
                        <?php echo e(trans('general.tax_number')); ?>: <?php echo e($invoice->customer_tax_number); ?><br>
                        <?php endif; ?>
                        <?php echo $__env->yieldPushContent('tax_number_input_end'); ?>
                        <br>
                        <?php echo $__env->yieldPushContent('phone_input_start'); ?>
                        <?php if($invoice->customer_phone): ?>
                        <?php echo e($invoice->customer_phone); ?><br>
                        <?php endif; ?>
                        <?php echo $__env->yieldPushContent('phone_input_end'); ?>
                        <?php echo $__env->yieldPushContent('email_start'); ?>
                        <?php echo e($invoice->customer_email); ?>

                        <?php echo $__env->yieldPushContent('email_input_end'); ?>
                    </address>
                </div>
                <div class="col-xs-5">
                    <div class="table-responsive">
                        <table class="table no-border">
                            <tbody>
                                <?php echo $__env->yieldPushContent('invoice_number_input_start'); ?>
                                <tr>
                                    <th><?php echo e(trans('invoices.invoice_number')); ?>:</th>
                                    <td class="text-right"><?php echo e($invoice->invoice_number); ?></td>
                                </tr>
                                <?php echo $__env->yieldPushContent('invoice_number_input_end'); ?>
                                <?php echo $__env->yieldPushContent('order_number_input_start'); ?>
                                <?php if($invoice->order_number): ?>
                                <tr>
                                    <th><?php echo e(trans('invoices.order_number')); ?>:</th>
                                    <td class="text-right"><?php echo e($invoice->order_number); ?></td>
                                </tr>
                                <?php endif; ?>
                                <?php echo $__env->yieldPushContent('order_number_input_end'); ?>
                                <?php echo $__env->yieldPushContent('invoiced_at_input_start'); ?>
                                <tr>
                                    <th><?php echo e(trans('invoices.invoice_date')); ?>:</th>
                                    <td class="text-right"><?php echo e(Date::parse($invoice->invoiced_at)->format($date_format)); ?></td>
                                </tr>
                                <?php echo $__env->yieldPushContent('invoiced_at_input_end'); ?>
                                <?php echo $__env->yieldPushContent('due_at_input_start'); ?>
                                <tr>
                                    <th><?php echo e(trans('invoices.payment_due')); ?>:</th>
                                    <td class="text-right"><?php echo e(Date::parse($invoice->due_at)->format($date_format)); ?></td>
                                </tr>
                                <?php echo $__env->yieldPushContent('due_at_input_end'); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-xs-12 table-responsive">
                    <table class="table table-striped">
                        <tbody>
                            <tr>
                                <?php echo $__env->yieldPushContent('actions_th_start'); ?>
                                <?php echo $__env->yieldPushContent('actions_th_end'); ?>
                                <?php echo $__env->yieldPushContent('name_th_start'); ?>
                                <th><?php echo e(trans_choice($text_override['items'], 2)); ?></th>
                                <?php echo $__env->yieldPushContent('name_th_end'); ?>
                                <?php echo $__env->yieldPushContent('quantity_th_start'); ?>
                                <th class="text-center"><?php echo e(trans($text_override['quantity'])); ?></th>
                                <?php echo $__env->yieldPushContent('quantity_th_end'); ?>
                                <?php echo $__env->yieldPushContent('price_th_start'); ?>
                                <th class="text-right"><?php echo e(trans($text_override['price'])); ?></th>
                                <?php echo $__env->yieldPushContent('price_th_end'); ?>
                                <?php echo $__env->yieldPushContent('taxes_th_start'); ?>
                                <?php echo $__env->yieldPushContent('taxes_th_end'); ?>
                                <?php echo $__env->yieldPushContent('total_th_start'); ?>
                                <th class="text-right"><?php echo e(trans('invoices.total')); ?></th>
                                <?php echo $__env->yieldPushContent('total_th_end'); ?>
                            </tr>
                            <?php $__currentLoopData = $invoice->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <?php echo $__env->yieldPushContent('actions_td_start'); ?>
                                <?php echo $__env->yieldPushContent('actions_td_end'); ?>
                                <?php echo $__env->yieldPushContent('name_td_start'); ?>
                                <td>
                                    <?php echo e($item->name); ?>

                                    <?php if($item->sku): ?>
                                        <br><small><?php echo e(trans('items.sku')); ?>: <?php echo e($item->sku); ?></small>
                                    <?php endif; ?>
                                </td>
                                <?php echo $__env->yieldPushContent('name_td_end'); ?>
                                <?php echo $__env->yieldPushContent('quantity_td_start'); ?>
                                <td class="text-center"><?php echo e($item->quantity); ?></td>
                                <?php echo $__env->yieldPushContent('quantity_td_end'); ?>
                                <?php echo $__env->yieldPushContent('price_td_start'); ?>
                                <td class="text-right"><?php echo money($item->price, $invoice->currency_code, true); ?></td>
                                <?php echo $__env->yieldPushContent('price_td_end'); ?>
                                <?php echo $__env->yieldPushContent('taxes_td_start'); ?>
                                <?php echo $__env->yieldPushContent('taxes_td_end'); ?>
                                <?php echo $__env->yieldPushContent('total_td_start'); ?>
                                <td class="text-right"><?php echo money($item->total, $invoice->currency_code, true); ?></td>
                                <?php echo $__env->yieldPushContent('total_td_end'); ?>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="row">
                <div class="col-xs-7">
                <?php echo $__env->yieldPushContent('notes_input_start'); ?>
                <?php if($invoice->notes): ?>
                    <p class="lead"><?php echo e(trans_choice('general.notes', 2)); ?></p>

                    <p class="text-muted well well-sm no-shadow" style="margin-top: 10px;">
                        <?php echo e($invoice->notes); ?>

                    </p>
                <?php endif; ?>
                <?php echo $__env->yieldPushContent('notes_input_end'); ?>
                </div>
                <div class="col-xs-5">
                    <div class="table-responsive">
                        <table class="table">
                            <tbody>
                                <?php $__currentLoopData = $invoice->totals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $total): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($total->code != 'total'): ?>
                                    <?php echo $__env->yieldPushContent($total->code . '_td_start'); ?>
                                    <tr>
                                        <th><?php echo e(trans($total->title)); ?>:</th>
                                        <td class="text-right"><?php echo money($total->amount, $invoice->currency_code, true); ?></td>
                                    </tr>
                                    <?php echo $__env->yieldPushContent($total->code . '_td_end'); ?>
                                <?php else: ?>
                                    <?php if($invoice->paid): ?>
                                        <tr class="text-success">
                                            <th><?php echo e(trans('invoices.paid')); ?>:</th>
                                            <td class="text-right">- <?php echo money($invoice->paid, $invoice->currency_code, true); ?></td>
                                        </tr>
                                    <?php endif; ?>
                                    <?php echo $__env->yieldPushContent('grand_total_td_start'); ?>
                                    <tr>
                                        <th><?php echo e(trans($total->name)); ?>:</th>
                                        <td class="text-right"><?php echo money($total->amount - $invoice->paid, $invoice->currency_code, true); ?></td>
                                    </tr>
                                    <?php echo $__env->yieldPushContent('grand_total_td_end'); ?>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="box-footer row no-print">
                <div class="col-md-12">
                    <?php if(!$invoice->reconciled): ?>
                    <a href="<?php echo e(url('incomes/invoices/' . $invoice->id . '/edit')); ?>" class="btn btn-default">
                        <i class="fa fa-pencil-square-o"></i>&nbsp; <?php echo e(trans('general.edit')); ?>

                    </a>
                    <?php endif; ?>
                    <a href="<?php echo e(url('incomes/invoices/' . $invoice->id . '/print')); ?>" target="_blank" class="btn btn-success">
                        <i class="fa fa-print"></i>&nbsp; <?php echo e(trans('general.print')); ?>

                    </a>
                    <a href="<?php echo e($customer_share); ?>" target="_blank" class="btn btn-primary">
                        <i class="fa fa-share"></i>&nbsp; Share
                    </a>
                    <div class="btn-group dropup">
                        <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-chevron-circle-up"></i>&nbsp; <?php echo e(trans('general.more_actions')); ?></button>
                        <ul class="dropdown-menu" role="menu">
                            <?php if($invoice->status->code != 'paid'): ?>
                            <?php if (app('laratrust')->can('update-incomes-invoices')) : ?>
                            <li><a href="<?php echo e(url('incomes/invoices/' . $invoice->id . '/pay')); ?>"><?php echo e(trans('invoices.mark_paid')); ?></a></li>
                            <?php endif; // app('laratrust')->can ?>
                            <?php if(empty($invoice->paid) || ($invoice->paid != $invoice->amount)): ?>
                            <li><a href="#" id="button-payment"><?php echo e(trans('invoices.add_payment')); ?></a></li>
                            <?php endif; ?>
                            <li class="divider"></li>
                            <?php endif; ?>
                            <?php if (app('laratrust')->can('update-incomes-invoices')) : ?>
                            <?php if($invoice->invoice_status_code == 'draft'): ?>
                            <li><a href="<?php echo e(url('incomes/invoices/' . $invoice->id . '/sent')); ?>"><?php echo e(trans('invoices.mark_sent')); ?></a></li>
                            <?php else: ?>
                            <li><a href="javascript:void(0);" class="disabled"><span class="text-disabled"><?php echo e(trans('invoices.mark_sent')); ?></span></a></li>
                            <?php endif; ?>
                            <?php endif; // app('laratrust')->can ?>
                            <?php if($invoice->customer_email): ?>
                            <li><a href="<?php echo e(url('incomes/invoices/' . $invoice->id . '/email')); ?>"><?php echo e(trans('invoices.send_mail')); ?></a></li>
                            <?php else: ?>
                            <li><a href="javascript:void(0);" class="green-tooltip disabled" data-toggle="tooltip" data-placement="right" title="<?php echo e(trans('invoices.messages.email_required')); ?>"><span class="text-disabled"><?php echo e(trans('invoices.send_mail')); ?></span></a></li>
                            <?php endif; ?>
                            <li class="divider"></li>
                            <li><a href="<?php echo e(url('incomes/invoices/' . $invoice->id . '/pdf')); ?>"><?php echo e(trans('invoices.download_pdf')); ?></a></li>
                            <?php if (app('laratrust')->can('delete-incomes-invoices')) : ?>
                            <?php if(!$invoice->reconciled): ?>
                            <li class="divider"></li>
                            <li><?php echo Form::deleteLink($invoice, 'incomes/invoices'); ?></li>
                            <?php endif; ?>
                            <?php endif; // app('laratrust')->can ?>
                        </ul>
                    </div>

                    <?php if($invoice->attachment): ?>
                        <span class="attachment">
                            <a href="<?php echo e(url('uploads/' . $invoice->attachment->id . '/download')); ?>">
                                <span id="download-attachment" class="text-primary">
                                    <i class="fa fa-file-<?php echo e($invoice->attachment->aggregate_type); ?>-o"></i> <?php echo e($invoice->attachment->basename); ?>

                                </span>
                            </a>
                            <?php echo Form::open([
                                'id' => 'attachment-' . $invoice->attachment->id,
                                'method' => 'DELETE',
                                'url' => [url('uploads/' . $invoice->attachment->id)],
                                'style' => 'display:inline'
                            ]); ?>

                            <a id="remove-attachment" href="javascript:void();">
                                <span class="text-danger"><i class="fa fa fa-times"></i></span>
                            </a>
                            <?php echo Form::close(); ?>

                        </span>
                    <?php endif; ?>
                </div>
            </div>
        </section>
    </div>

    <div class="row">
        <div class="col-xs-6">
            <div class="box box-default collapsed-box">
                <div class="box-header with-border">
                    <h3 class="box-title"><?php echo e(trans('invoices.histories')); ?></h3>

                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-plus"></i></button>
                    </div>
                    <!-- /.box-tools -->
                </div>
                <div class="box-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                            <tr>
                                <th><?php echo e(trans('general.date')); ?></th>
                                <th><?php echo e(trans_choice('general.statuses', 1)); ?></th>
                                <th><?php echo e(trans('general.description')); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $invoice->histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(Date::parse($history->created_at)->format($date_format)); ?></td>
                                    <td><?php echo e($history->status->name); ?></td>
                                    <td><?php echo e($history->description); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xs-6">
            <div class="box box-default collapsed-box">
                <div class="box-header with-border">
                    <h3 class="box-title"><?php echo e(trans('invoices.payments')); ?></h3>

                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-plus"></i></button>
                    </div>
                    <!-- /.box-tools -->
                </div>
                <div class="box-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                            <tr>
                                <th><?php echo e(trans('general.date')); ?></th>
                                <th><?php echo e(trans('general.amount')); ?></th>
                                <th><?php echo e(trans_choice('general.accounts', 1)); ?></th>
                                <th style="width: 15%;"><?php echo e(trans('general.actions')); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $invoice->payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(Date::parse($payment->paid_at)->format($date_format)); ?></td>
                                    <td><?php echo money($payment->amount, $payment->currency_code, true); ?></td>
                                    <td><?php echo e($payment->account->name); ?></td>
                                    <td>
                                        <?php if($payment->reconciled): ?>
                                        <button type="button" class="btn btn-default btn-xs">
                                            <i class="fa fa-check"></i> <?php echo e(trans('reconciliations.reconciled')); ?>

                                        </button>
                                        <?php else: ?>
                                        <a href="<?php echo e(url('incomes/invoices/' . $payment->id . '')); ?>" class="btn btn-info btn-xs hidden"><i class="fa fa-eye" aria-hidden="true"></i> <?php echo e(trans('general.show')); ?></a>
                                        <a href="<?php echo e(url('incomes/revenues/' . $payment->id . '/edit')); ?>" class="btn btn-primary btn-xs  hidden"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> <?php echo e(trans('general.edit')); ?></a>
                                        <?php echo Form::open([
                                            'id' => 'invoice-payment-' . $payment->id,
                                            'method' => 'DELETE',
                                            'url' => ['incomes/invoices/payment', $payment->id],
                                            'style' => 'display:inline'
                                        ]); ?>

                                        <?php echo Form::button('<i class="fa fa-trash-o" aria-hidden="true"></i> ' . trans('general.delete'), array(
                                            'type'    => 'button',
                                            'class'   => 'btn btn-danger btn-xs',
                                            'title'   => trans('general.delete'),
                                            'onclick' => 'confirmDelete("' . '#invoice-payment-' . $payment->id . '", "' . trans_choice('general.payments', 2) . '", "' . trans('general.delete_confirm', ['name' => '<strong>' . Date::parse($payment->paid_at)->format($date_format) . ' - ' . money($payment->amount, $payment->currency_code, true) . ' - ' . $payment->account->name . '</strong>', 'type' => strtolower(trans_choice('general.revenues', 1))]) . '", "' . trans('general.cancel') . '", "' . trans('general.delete') . '")'
                                        )); ?>

                                        <?php echo Form::close(); ?>

                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('vendor/almasaeed2010/adminlte/plugins/datepicker/bootstrap-datepicker.js')); ?>"></script>
    <?php if(language()->getShortCode() != 'en'): ?>
    <script src="<?php echo e(asset('vendor/almasaeed2010/adminlte/plugins/datepicker/locales/bootstrap-datepicker.' . language()->getShortCode() . '.js')); ?>"></script>
    <?php endif; ?>
    <script src="<?php echo e(asset('public/js/bootstrap-fancyfile.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('vendor/almasaeed2010/adminlte/plugins/datepicker/datepicker3.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/css/bootstrap-fancyfile.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript">
        <?php if($invoice->attachment): ?>
        $(document).on('click', '#remove-attachment', function (e) {
            confirmDelete("#attachment-<?php echo $invoice->attachment->id; ?>", "<?php echo trans('general.attachment'); ?>", "<?php echo trans('general.delete_confirm', ['name' => '<strong>' . $invoice->attachment->basename . '</strong>', 'type' => strtolower(trans('general.attachment'))]); ?>", "<?php echo trans('general.cancel'); ?>", "<?php echo trans('general.delete'); ?>");
        });
        <?php endif; ?>

        $(document).on('click', '#button-payment', function (e) {
            $('#modal-add-payment').remove();

            $.ajax({
                url: '<?php echo e(url("modals/invoices/" . $invoice->id . "/payment/create")); ?>',
                type: 'GET',
                dataType: 'JSON',
                success: function(json) {
                    if (json['success']) {
                        $('body').append(json['html']);
                    }
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>