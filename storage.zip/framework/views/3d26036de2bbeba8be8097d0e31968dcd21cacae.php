<?php $__env->startSection('title', trans('reports.profit_loss')); ?>

<?php $__env->startSection('content'); ?>
    <div class="box-header">
        <h2><?php echo e(trans('reports.profit_loss')); ?></h2>
        <div class="text-muted">
            <?php echo e(setting('general.company_name')); ?>

            <br/>
            <?php echo e(Date::parse(request('year') . '-1-1')->format($date_format)); ?> - <?php echo e(Date::parse(request('year') . '-12-31')->format($date_format)); ?>

        </div>
    </div>
    <?php echo $__env->make('reports.profit_loss.body', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.print', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>