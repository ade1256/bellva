<div class="col-md-12 no-padding-left">
    <div class="box box-success">
        <div class="box-header with-border">

            <div class="pull-left">
                <?php echo Form::select('category', $categories, request('category'), ['class' => 'form-control input-sm', 'style' => 'display:inline;width:inherit;']); ?>

                <a href="<?php echo e(url('apps/paid')); ?>" class="btn btn-sm btn-default btn-flat margin" style="margin-left: 20px;"><?php echo e(trans('modules.top_paid')); ?></a>
                <a href="<?php echo e(url('apps/new')); ?>" class="btn btn-sm btn-default btn-flat margin"><?php echo e(trans('modules.new')); ?></a>
                <a href="<?php echo e(url('apps/free')); ?>" class="btn btn-sm btn-default btn-flat margin"><?php echo e(trans('modules.top_free')); ?></a>
            </div>

            <div class="pull-right">
                <div class="has-feedback">
                    <?php echo Form::open(['url' => 'apps/search', 'role' => 'form', 'method' => 'GET']); ?>

                    <input name="keyword" value="<?php echo e(isset($keyword) ? $keyword : ''); ?>" type="text" class="form-control input-sm" style="margin-top: 10px;" placeholder="Search Apps">
                    <span class="glyphicon glyphicon-search form-control-feedback"></span>
                    <?php echo Form::close(); ?>

                </div>
            </div>

        </div>
    </div>
</div>