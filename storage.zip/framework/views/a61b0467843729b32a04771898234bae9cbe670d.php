<html lang="<?php echo e(setting('general.default_locale')); ?>">
    <?php echo $__env->make('partials.wizard.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <body class="hold-transition <?php echo e(setting('general.admin_theme', 'skin-green-light')); ?> sidebar-mini fixed">
        <?php echo $__env->yieldPushContent('body_start'); ?>

        <!-- Site wrapper -->
        <div class="wrapper">
            <?php echo $__env->make('partials.wizard.content', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>

        <?php echo $__env->yieldPushContent('body_end'); ?>

        <script type="text/javascript">
            $('#wizard-skip, .stepwizard .btn.btn-default').on('click', function() {
                $('#wizard-loading').html('<span class="wizard-loading-bar"><span class="wizard-loading-spin"><i class="fa fa-spinner fa-spin"></i></span></span>');
            });
        </script>
    </body>
</html>
