<?php $__env->startSection('title', trans('general.title.new', ['type' => trans_choice('general.currencies', 1)])); ?>

<?php $__env->startSection('content'); ?>
    <!-- Default box -->
    <div class="box box-success">
    <?php echo Form::open(['url' => 'settings/currencies', 'role' => 'form', 'class' => 'form-loading-button']); ?>


    <div class="box-body">
        <?php echo e(Form::textGroup('name', trans('general.name'), 'id-card-o')); ?>


        <?php echo e(Form::selectGroup('code', trans('currencies.code'), 'code', $codes)); ?>


        <?php echo e(Form::textGroup('rate', trans('currencies.rate'), 'money')); ?>


        <?php echo e(Form::numberGroup('precision', trans('currencies.precision'), 'bullseye')); ?>


        <?php echo e(Form::textGroup('symbol', trans('currencies.symbol.symbol'), 'font')); ?>


        <?php echo e(Form::selectGroup('symbol_first', trans('currencies.symbol.position'), 'text-width', ['1' => trans('currencies.symbol.before'), '0' => trans('currencies.symbol.after')])); ?>


        <?php echo e(Form::textGroup('decimal_mark', trans('currencies.decimal_mark'), 'columns')); ?>


        <?php echo e(Form::textGroup('thousands_separator', trans('currencies.thousands_separator'), 'columns', [])); ?>


        <?php echo e(Form::radioGroup('enabled', trans('general.enabled'))); ?>


        <?php echo e(Form::radioGroup('default_currency', trans('currencies.default'))); ?>

    </div>
    <!-- /.box-body -->

    <div class="box-footer">
        <?php echo e(Form::saveButtons('settings/currencies')); ?>

    </div>
    <!-- /.box-footer -->

    <?php echo Form::close(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript">
        var text_yes = '<?php echo e(trans('general.yes')); ?>';
        var text_no = '<?php echo e(trans('general.no')); ?>';

        $(document).ready(function(){
            $('#enabled_1').trigger('click');

            $('#name').focus();

            $("#code").select2({
                placeholder: "<?php echo e(trans('general.form.select.field', ['field' => trans('currencies.code')])); ?>"
            });

            $('#code').change(function() {
                $.ajax({
                    url: '<?php echo e(url("settings/currencies/config")); ?>',
                    type: 'GET',
                    dataType: 'JSON',
                    data: 'code=' + $(this).val(),
                    success: function(data) {
                        $('#precision').val(data.precision);
                        $('#symbol').val(data.symbol);
                        $('#symbol_first').val(data.symbol_first);
                        $('#decimal_mark').val(data.decimal_mark);
                        $('#thousands_separator').val(data.thousands_separator);

                        // This event Select2 Stylesheet
                        $('#symbol_first').trigger('change');
                    }
                });
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>