<?php $__env->startSection('title', trans('modules.title')); ?>

<?php $__env->startSection('content'); ?>
    <div class="box box-success">
        <?php echo Form::open(['url' => 'apps/token', 'files' => true, 'role' => 'form', 'class' => 'form-loading-button']); ?>


        <div class="box-body">
            <div class="col-md-12">
                <div class="form-group required <?php echo e($errors->has('api_token') ? 'has-error' : ''); ?>">
                    <?php echo Form::label('sale_price', trans('modules.api_token'), ['class' => 'control-label']); ?>

                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-key"></i></span>
                        <?php echo Form::text('api_token', setting('general.api_token', null), ['class' => 'form-control', 'required' => 'required', 'placeholder' => trans('general.form.enter', ['field' => trans('modules.api_token')])]); ?>

                    </div>
                    <?php echo $errors->first('api_token', '<p class="help-block">:message</p>'); ?>

                </div>
                <p>
                    <?php echo trans('modules.token_link'); ?>

                </p>
            </div>
        </div>
        <!-- /.box-body -->

        <div class="box-footer">
            <?php echo e(Form::saveButtons('apps/home')); ?>

        </div>

        <?php echo Form::close(); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.modules', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>