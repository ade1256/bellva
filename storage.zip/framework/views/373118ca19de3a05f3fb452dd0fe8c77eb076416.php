<div class="modal fade" id="modal-add-payment" style="display: none;">
    <div class="modal-dialog  modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title"><?php echo e(trans('general.title.new', ['type' => trans_choice('general.payments', 1)])); ?></h4>
            </div>
            <div class="modal-body">
                <div class="modal-message"></div>
                <?php echo Form::open(['id' => 'form-add-payment', 'role' => 'form', 'class' => 'form-loading-button']); ?>

                <div class="row">
                    <?php echo e(Form::textGroup('paid_at', trans('general.date'), 'calendar',['id' => 'paid_at', 'class' => 'form-control', 'required' => 'required', 'data-inputmask' => '\'alias\': \'yyyy-mm-dd\'', 'data-mask' => '', 'autocomplete' => 'off'], Date::now()->toDateString())); ?>


                    <?php echo e(Form::textGroup('amount', trans('general.amount'), 'money', ['required' => 'required', 'autofocus' => 'autofocus'], $invoice->grand_total)); ?>


                    <?php echo e(Form::selectGroup('account_id', trans_choice('general.accounts', 1), 'university', $accounts, setting('general.default_account'))); ?>


                    <?php echo $__env->yieldPushContent('currency_code_input_start'); ?>
                    <div class="form-group col-md-6 required">
                        <?php echo Form::label('currency_code', trans_choice('general.currencies', 1), ['class' => 'control-label']); ?>

                        <div class="input-group">
                            <div class="input-group-addon"><i class="fa fa-exchange"></i></div>
                            <?php echo Form::text('currency', $currencies[$invoice->currency_code], ['id' => 'currency', 'class' => 'form-control', 'required' => 'required', 'disabled' => 'disabled']); ?>

                            <?php echo Form::hidden('currency_code', $invoice->currency_code, ['id' => 'currency_code', 'class' => 'form-control', 'required' => 'required']); ?>

                        </div>
                    </div>
                    <?php echo $__env->yieldPushContent('currency_code_input_end'); ?>

                    <?php echo e(Form::textareaGroup('description', trans('general.description'))); ?>


                    <?php echo e(Form::selectGroup('payment_method', trans_choice('general.payment_methods', 1), 'credit-card', $payment_methods, setting('general.default_payment_method'))); ?>


                    <?php echo e(Form::textGroup('reference', trans('general.reference'), 'file-text-o',[])); ?>


                    <?php echo Form::hidden('invoice_id', $invoice->id, ['id' => 'invoice_id', 'class' => 'form-control', 'required' => 'required']); ?>

                </div>
                <?php echo Form::close(); ?>

            </div>
            <div class="modal-footer">
                <div class="pull-left">
                    <?php echo Form::button('<span class="fa fa-save"></span> &nbsp;' . trans('general.save'), ['type' => 'button', 'id' =>'button-add-payment', 'class' => 'btn btn-success button-submit', 'data-loading-text' => trans('general.loading')]); ?>

                    <button type="button" class="btn btn-default" data-dismiss="modal"><span class="fa fa-times-circle"></span> &nbsp;<?php echo e(trans('general.cancel')); ?></button>
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    $('#modal-add-payment #amount').focus();

    $(document).ready(function(){
        $('#modal-add-payment').modal('show');

        $("#modal-add-payment #amount").maskMoney({
            thousands : '<?php echo e($currency->thousands_separator); ?>',
            decimal : '<?php echo e($currency->decimal_mark); ?>',
            precision : <?php echo e($currency->precision); ?>,
            allowZero : true,
            <?php if($currency->symbol_first): ?>
            prefix : '<?php echo e($currency->symbol); ?>'
            <?php else: ?>
            suffix : '<?php echo e($currency->symbol); ?>'
            <?php endif; ?>
        });

        $('#modal-add-payment #amount').trigger('focusout');

        $('#modal-add-payment #paid_at').datepicker({
            format: 'yyyy-mm-dd',
            todayBtn: 'linked',
            weekStart: 1,
            autoclose: true,
            language: '<?php echo e(language()->getShortCode()); ?>'
        });

        $("#modal-add-payment #account_id").select2({
            placeholder: "<?php echo e(trans('general.form.select.field', ['field' => trans_choice('general.accounts', 1)])); ?>"
        });

        $("#modal-add-payment #payment_method").select2({
            placeholder: "<?php echo e(trans('general.form.select.field', ['field' => trans_choice('general.payment_methods', 1)])); ?>"
        });
    });

    $(document).on('change', '#modal-add-payment  #account_id', function (e) {
        $.ajax({
            url: '<?php echo e(url("banking/accounts/currency")); ?>',
            type: 'GET',
            dataType: 'JSON',
            data: 'account_id=' + $(this).val(),
            success: function(data) {
                $('#modal-add-payment  #currency').val(data.currency_name);
                $('#modal-add-payment  #currency_code').val(data.currency_code);

                amount = $('#modal-add-payment  #amount').maskMoney('unmasked')[0];

                $("#modal-add-payment  #amount").maskMoney({
                    thousands : data.thousands_separator,
                    decimal : data.decimal_mark,
                    precision : data.precision,
                    allowZero : true,
                    prefix : (data.symbol_first) ? data.symbol : '',
                    suffix : (data.symbol_first) ? '' : data.symbol
                });

                $('#modal-add-payment  #amount').val(amount);

                $('#modal-add-payment #amount').focus();
            }
        });
    });

    $(document).on('click', '#button-add-payment', function (e) {
        $('.help-block').remove();

        $.ajax({
            url: '<?php echo e(url("modals/invoices/" . $invoice->id . "/payment")); ?>',
            type: 'POST',
            dataType: 'JSON',
            data: $("#form-add-payment").serialize(),
            headers: { 'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>' },
            beforeSend: function() {
                $('#button-add-payment').button('loading');

                $('#modal-add-payment .modal-content').append('<div id="loading" class="text-center"><i class="fa fa-spinner fa-spin fa-5x checkout-spin"></i></div>');
            },
            complete: function() {
                $('#button-add-payment').button('reset');
                $('#loading').remove();
            },
            success: function(json) {
                if (json['error']) {
                    $('#modal-add-payment .modal-message').append('<div class="alert alert-danger">' + json['message'] + '</div>');
                    $('div.alert-danger').delay(3000).fadeOut(350);
                }

                if (json['success']) {
                    $('#modal-add-payment .modal-message').before('<div class="alert alert-success">' + json['message'] + '</div>');
                    $('div.alert-success').delay(3000).fadeOut(350);

                    setTimeout(function(){
                        $("#modal-add-payment").modal('hide');

                        location.reload();
                    }, 3000);
                }
            },
            error: function(data){
                var errors = data.responseJSON;

                if (typeof errors !== 'undefined') {
                    if (errors.paid_at) {
                        $('#modal-add-payment #paid_at').parent().after('<p class="help-block">' + errors.paid_at + '</p>');
                    }

                    if (errors.amount) {
                        $('#modal-add-payment #amount').parent().after('<p class="help-block">' + errors.amount + '</p>');
                    }

                    if (errors.account_id) {
                        $('#modal-add-payment #account_id').parent().after('<p class="help-block">' + errors.account_id + '</p>');
                    }

                    if (errors.currency_code) {
                        $('#modal-add-payment #currency_code').parent().after('<p class="help-block">' + errors.currency_code + '</p>');
                    }

                    if (errors.category_id) {
                        $('#modal-add-payment #category_id').parent().after('<p class="help-block">' + errors.category_id + '</p>');
                    }

                    if (errors.payment_method) {
                        $('#modal-add-payment #payment_method').parent().after('<p class="help-block">' + errors.payment_method + '</p>');
                    }
                }
            }
        });
    });
</script>
