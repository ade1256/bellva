<?php $__env->startSection('title', trans('general.dashboard')); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <!---Income-->
        <div class="col-md-4">
            <div class="info-box">
                <?php if($auth_user->can('read-reports-income-summary')): ?>
                <a href="<?php echo e(url('reports/income-summary')); ?>"><span class="info-box-icon bg-aqua"><i class="fa fa-money"></i></span></a>
                <?php else: ?>
                <span class="info-box-icon bg-aqua"><i class="fa fa-money"></i></span>
                <?php endif; ?>

                <div class="info-box-content">
                    <span class="info-box-text"><?php echo e(trans('dashboard.total_incomes')); ?></span>
                    <span class="info-box-number"><?php echo money($total_incomes['total'], setting('general.default_currency'), true); ?></span>
                    <div class="progress-group" title="<?php echo e(trans('dashboard.open_invoices')); ?>: <?php echo e($total_incomes['open_invoice']); ?><br><?php echo e(trans('dashboard.overdue_invoices')); ?>: <?php echo e($total_incomes['overdue_invoice']); ?>" data-toggle="tooltip" data-html="true">
                        <div class="progress sm">
                            <div class="progress-bar progress-bar-aqua" style="width: <?php echo e($total_incomes['progress']); ?>%"></div>
                        </div>
                        <span class="progress-text"><?php echo e(trans('dashboard.receivables')); ?></span>
                        <span class="progress-number"><?php echo e($total_incomes['open_invoice']); ?> / <?php echo e($total_incomes['overdue_invoice']); ?></span>
                    </div>
                </div>
            </div>
        </div>

        <!---Expense-->
        <div class="col-md-4">
            <div class="info-box">
                <?php if($auth_user->can('read-reports-expense-summary')): ?>
                <a href="<?php echo e(url('reports/expense-summary')); ?>"><span class="info-box-icon bg-red"><i class="fa fa-shopping-cart"></i></span></a>
                <?php else: ?>
                <span class="info-box-icon bg-red"><i class="fa fa-shopping-cart"></i></span>
                <?php endif; ?>

                <div class="info-box-content">
                    <span class="info-box-text"><?php echo e(trans('dashboard.total_expenses')); ?></span>
                    <span class="info-box-number"><?php echo money($total_expenses['total'], setting('general.default_currency'), true); ?></span>

                    <div class="progress-group" title="<?php echo e(trans('dashboard.open_bills')); ?>: <?php echo e($total_expenses['open_bill']); ?><br><?php echo e(trans('dashboard.overdue_bills')); ?>: <?php echo e($total_expenses['overdue_bill']); ?>" data-toggle="tooltip" data-html="true">
                        <div class="progress sm">
                            <div class="progress-bar progress-bar-red" style="width: <?php echo e($total_expenses['progress']); ?>%"></div>
                        </div>
                        <span class="progress-text"><?php echo e(trans('dashboard.payables')); ?></span>
                        <span class="progress-number"><?php echo e($total_expenses['open_bill']); ?> / <?php echo e($total_expenses['overdue_bill']); ?></span>
                    </div>
                </div>
            </div>
        </div>

        <!---Profit-->
        <div class="col-md-4">
            <div class="info-box">
                <?php if($auth_user->can('read-reports-income-expense-summary')): ?>
                <a href="<?php echo e(url('reports/income-expense-summary')); ?>"><span class="info-box-icon bg-green"><i class="fa fa-heart"></i></span></a>
                <?php else: ?>
                <span class="info-box-icon bg-green"><i class="fa fa-heart"></i></span>
                <?php endif; ?>

                <div class="info-box-content">
                    <span class="info-box-text"><?php echo e(trans('dashboard.total_profit')); ?></span>
                    <span class="info-box-number"><?php echo money($total_profit['total'], setting('general.default_currency'), true); ?></span>

                    <div class="progress-group" title="<?php echo e(trans('dashboard.open_profit')); ?>: <?php echo e($total_profit['open']); ?><br><?php echo e(trans('dashboard.overdue_profit')); ?>: <?php echo e($total_profit['overdue']); ?>" data-toggle="tooltip" data-html="true">
                        <div class="progress sm">
                            <div class="progress-bar progress-bar-green" style="width: <?php echo e($total_profit['progress']); ?>%"></div>
                        </div>
                        <span class="progress-text"><?php echo e(trans('general.upcoming')); ?></span>
                        <span class="progress-number"><?php echo e($total_profit['open']); ?> / <?php echo e($total_profit['overdue']); ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <!---Income, Expense and Profit Line Chart-->
        <div class="col-md-12">
            <div class="box box-success">
                <div class="box-header with-border">
                    <h3 class="box-title"><?php echo e(trans('dashboard.cash_flow')); ?></h3>
                    <div class="box-tools pull-right">
                        <button type="button" id="cashflow-monthly" class="btn btn-default btn-sm"><?php echo e(trans('general.monthly')); ?></button>&nbsp;&nbsp;
                        <button type="button" id="cashflow-quarterly" class="btn btn-default btn-sm"><?php echo e(trans('general.quarterly')); ?></button>&nbsp;&nbsp;
                        <input type="hidden" name="period" id="period" value="month" />
                        <div class="btn btn-default btn-sm">
                            <div id="cashflow-range" class="pull-right">
                                <i class="glyphicon glyphicon-calendar fa fa-calendar"></i>&nbsp;
                                <span></span> <b class="caret"></b>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="box-body" id="cashflow">
                    <?php echo $cashflow->render(); ?>

                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6">
            <div class="box box-success">
                <div class="box-header with-border">
                    <h3 class="box-title"><?php echo e(trans('dashboard.incomes_by_category')); ?></h3>
                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                    </div>
                </div>
                <div class="box-body">
                    <?php echo $donut_incomes->render(); ?>

                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="box box-success">
                <div class="box-header with-border">
                    <h3 class="box-title"><?php echo e(trans('dashboard.expenses_by_category')); ?></h3>
                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                    </div>
                </div>
                <div class="box-body">
                    <?php echo $donut_expenses->render(); ?>

                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- Account Balance List-->
        <div class="col-md-4">
            <div class="box box-success">
                <div class="box-header with-border">
                    <h3 class="box-title"><?php echo e(trans('dashboard.account_balance')); ?></h3>
                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                    </div>
                </div>
                <div class="box-body">
                    <?php if($accounts->count()): ?>
                        <table class="table table-striped">
                            <tbody>
                                <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-left"><?php echo e($item->name); ?></td>
                                    <td class="text-right"><?php echo money($item->balance, $item->currency_code, true); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <h5 class="text-center"><?php echo e(trans('general.no_records')); ?></h5>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Latest Incomes List-->
        <div class="col-md-4">
            <div class="box box-success">
                <div class="box-header with-border">
                    <h3 class="box-title"><?php echo e(trans('dashboard.latest_incomes')); ?></h3>
                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                    </div>
                </div>
                <div class="box-body">
                    <?php if($latest_incomes->count()): ?>
                    <table class="table table-striped">
                        <thead>
                        <tr>
                            <th class="text-left"><?php echo e(trans('general.date')); ?></th>
                            <th class="text-left"><?php echo e(trans_choice('general.categories', 1)); ?></th>
                            <th class="text-right"><?php echo e(trans('general.amount')); ?></th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $latest_incomes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-left"><?php echo e(Date::parse($item->paid_at)->format($date_format)); ?></td>
                                <td class="text-left"><?php echo e($item->category ? $item->category->name : trans_choice('general.invoices', 2)); ?></td>
                                <td class="text-right"><?php echo money($item->amount, $item->currency_code, true); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php else: ?>
                    <h5 class="text-center"><?php echo e(trans('general.no_records')); ?></h5>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Latest Expenses List-->
        <div class="col-md-4">
            <div class="box box-success">
                <div class="box-header with-border">
                    <h3 class="box-title"><?php echo e(trans('dashboard.latest_expenses')); ?></h3>
                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                    </div>
                </div>
                <div class="box-body">
                    <?php if($latest_expenses->count()): ?>
                    <table class="table table-striped">
                        <thead>
                        <tr>
                            <th class="text-left"><?php echo e(trans('general.date')); ?></th>
                            <th class="text-left"><?php echo e(trans_choice('general.categories', 1)); ?></th>
                            <th class="text-right"><?php echo e(trans('general.amount')); ?></th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $latest_expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-left"><?php echo e(Date::parse($item->paid_at)->format($date_format)); ?></td>
                                <td class="text-left"><?php echo e($item->category ? $item->category->name : trans_choice('general.bills', 2)); ?></td>
                                <td class="text-right"><?php echo money($item->amount, $item->currency_code, true); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php else: ?>
                    <h5 class="text-center"><?php echo e(trans('general.no_records')); ?></h5>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/css/daterangepicker.css')); ?>" />
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
<?php echo Charts::assets(); ?>

<script type="text/javascript" src="<?php echo e(asset('public/js/moment/moment.js')); ?>"></script>
<?php if(is_file(base_path('public/js/moment/locale/' . strtolower(app()->getLocale()) . '.js'))): ?>
<script type="text/javascript" src="<?php echo e(asset('public/js/moment/locale/' . strtolower(app()->getLocale()) . '.js')); ?>"></script>
<?php elseif(is_file(base_path('public/js/moment/locale/' . language()->getShortCode() . '.js'))): ?>
<script type="text/javascript" src="<?php echo e(asset('public/js/moment/locale/' . language()->getShortCode() . '.js')); ?>"></script>
<?php endif; ?>
<script type="text/javascript" src="<?php echo e(asset('public/js/daterangepicker/daterangepicker.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    $(function() {
        var start = moment().startOf('year');
        var end = moment().endOf('year');

        function cb(start, end) {
            $('#cashflow-range span').html(start.format('D MMM YYYY') + ' - ' + end.format('D MMM YYYY'));
        }

        $('#cashflow-range').daterangepicker({
            startDate: start,
            endDate: end,
            ranges: {
                '<?php echo e(trans("reports.this_year")); ?>': [moment().startOf('year'), moment().endOf('year')],
                '<?php echo e(trans("reports.previous_year")); ?>': [moment().subtract(1, 'year').startOf('year'), moment().subtract(1, 'year').endOf('year')],
                '<?php echo e(trans("reports.this_quarter")); ?>': [moment().subtract(2, 'months').startOf('month'), moment().endOf('month')],
                '<?php echo e(trans("reports.previous_quarter")); ?>': [moment().subtract(5, 'months').startOf('month'), moment().subtract(3, 'months').endOf('month')],
                '<?php echo e(trans("reports.last_12_months")); ?>': [moment().subtract(11, 'months').startOf('month'), moment().endOf('month')]
            }
        }, cb);

        cb(start, end);
    });

    $(document).ready(function () {
        $('#cashflow-range').on('apply.daterangepicker', function(ev, picker) {
            var period = $('#period').val();

            range = getRange(picker);

            $.ajax({
                url: '<?php echo e(url("common/dashboard/cashflow")); ?>',
                type: 'get',
                dataType: 'html',
                data: 'period=' + period + '&start=' + picker.startDate.format('YYYY-MM-DD') + '&end=' + picker.endDate.format('YYYY-MM-DD') + '&range=' + range,
                success: function(data) {
                    $('#cashflow').html(data);
                }
            });
        });

        $('#cashflow-monthly').on('click', function() {
            var picker = $('#cashflow-range').data('daterangepicker');

            $('#period').val('month');

            range = getRange(picker);

            $.ajax({
                url: '<?php echo e(url("common/dashboard/cashflow")); ?>',
                type: 'get',
                dataType: 'html',
                data: 'period=month&start=' + picker.startDate.format('YYYY-MM-DD') + '&end=' + picker.endDate.format('YYYY-MM-DD') + '&range=' + range,
                success: function(data) {
                    $('#cashflow').html(data);
                }
            });
        });

        $('#cashflow-quarterly').on('click', function() {
            var picker = $('#cashflow-range').data('daterangepicker');

            $('#period').val('quarter');

            range = getRange(picker);

            $.ajax({
                url: '<?php echo e(url("common/dashboard/cashflow")); ?>',
                type: 'get',
                dataType: 'html',
                data: 'period=quarter&start=' + picker.startDate.format('YYYY-MM-DD') + '&end=' + picker.endDate.format('YYYY-MM-DD') + '&range=' + range,
                success: function(data) {
                    $('#cashflow').html(data);
                }
            });
        });
    });

    function getRange(picker) {
        ranges = {
            '<?php echo e(trans("reports.this_year")); ?>': 'this_year',
            '<?php echo e(trans("reports.previous_year")); ?>': 'previous_year',
            '<?php echo e(trans("reports.this_quarter")); ?>': 'this_quarter',
            '<?php echo e(trans("reports.previous_quarter")); ?>': 'previous_quarter',
            '<?php echo e(trans("reports.last_12_months")); ?>': 'last_12_months'
        };

        range = 'custom';

        if (ranges[picker.chosenLabel] != undefined) {
            range = ranges[picker.chosenLabel];
        }

        return range;
    }
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>