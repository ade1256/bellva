<?php $__env->startSection('title', trans_choice('general.modules', 2)); ?>

<?php $__env->startSection('new_button'); ?>
    <span class="new-button"><a href="<?php echo e(url('apps/token/create')); ?>" class="btn btn-success btn-sm"><span class="fa fa-key"></span> &nbsp;<?php echo e(trans('modules.api_token')); ?></a></span>
    <span class="new-button"><a href="<?php echo e(url('apps/my')); ?>" class="btn btn-default btn-sm"><span class="fa fa-user"></span> &nbsp;<?php echo e(trans('modules.my_apps')); ?></a></span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.modules.bar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="content-header no-padding-left">
                <h3><?php echo e(trans('modules.top_paid')); ?></h3>
            </div>

            <?php if($paid->data): ?>
                <?php $__currentLoopData = $paid->data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('partials.modules.item', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <?php echo $__env->make('partials.modules.no_apps', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php endif; ?>
        </div>

        <div class="col-md-12">
            <div class="content-header no-padding-left">
                <h3><?php echo e(trans('modules.new')); ?></h3>
            </div>

            <?php if($new->data): ?>
                <?php $__currentLoopData = $new->data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('partials.modules.item', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <?php echo $__env->make('partials.modules.no_apps', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php endif; ?>
        </div>

        <div class="col-md-12">
            <div class="content-header no-padding-left">
                <h3><?php echo e(trans('modules.top_free')); ?></h3>
            </div>

            <?php if($free->data): ?>
                <?php $__currentLoopData = $free->data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('partials.modules.item', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <?php echo $__env->make('partials.modules.no_apps', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.modules', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>