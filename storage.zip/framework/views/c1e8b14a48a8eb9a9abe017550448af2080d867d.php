<?php $__env->startSection('title', trans('general.general')); ?>

<?php $__env->startSection('content'); ?>
    <!-- Default box -->
    <div class="row">
        <?php echo Form::model($setting, [
            'method' => 'PATCH',
            'url' => ['settings/settings'],
            'class' => 'setting-form form-loading-button',
            'files' => true,
            'role' => 'form',
        ]); ?>


        <div class="col-sm-12">
            <div class="nav-tabs-custom">
                <ul class="nav nav-tabs">
                    <li class="active"><a href="#company" data-toggle="tab" aria-expanded="true"><?php echo e(trans_choice('general.companies', 1)); ?></a></li>
                    <li class=""><a href="#localisation" data-toggle="tab" aria-expanded="false"><?php echo e(trans('settings.localisation.tab')); ?></a></li>
                    <li class=""><a href="#invoice" data-toggle="tab" aria-expanded="false"><?php echo e(trans('settings.invoice.tab')); ?></a></li>
                    <li class=""><a href="#default" data-toggle="tab" aria-expanded="false"><?php echo e(trans('settings.default.tab')); ?></a></li>
                    <li class=""><a href="#email" data-toggle="tab" aria-expanded="false"><?php echo e(trans('general.email')); ?></a></li>
                    <li class=""><a href="#scheduling" data-toggle="tab" aria-expanded="false"><?php echo e(trans('settings.scheduling.tab')); ?></a></li>
                    <li class=""><a href="#appearance" data-toggle="tab" aria-expanded="false"><?php echo e(trans('settings.appearance.tab')); ?></a></li>
                    <li class=""><a href="#system" data-toggle="tab" aria-expanded="false"><?php echo e(trans('settings.system.tab')); ?></a></li>
                </ul>

                <div class="tab-content">
                    <div class="tab-pane tab-margin active" id="company">
                        <?php echo e(Form::textGroup('company_name', trans('settings.company.name'), 'id-card-o')); ?>


                        <?php echo e(Form::textGroup('company_email', trans('settings.company.email'), 'envelope')); ?>


                        <?php echo e(Form::textGroup('company_tax_number', trans('general.tax_number'), 'percent', [])); ?>


                        <?php echo e(Form::textGroup('company_phone', trans('settings.company.phone'), 'phone', [])); ?>


                        <?php echo e(Form::textareaGroup('company_address', trans('settings.company.address'))); ?>


                        <?php echo e(Form::fileGroup('company_logo', trans('settings.company.logo'))); ?>


                        <?php echo Form::hidden('wizard', null, ['id' => 'wizard']); ?>

                    </div>

                    <div class="tab-pane tab-margin" id="localisation">
                        <?php echo e(Form::selectGroup('date_format', trans('settings.localisation.date.format'), 'calendar', $date_formats, null, ['autocomplete' => 'off'])); ?>


                        <?php echo e(Form::selectGroup('date_separator', trans('settings.localisation.date.separator'), 'minus', $date_separators, null, [])); ?>


                        <?php echo e(Form::selectGroup('timezone', trans('settings.localisation.timezone'), 'globe', $timezones, null, [])); ?>


                        <?php echo e(Form::selectGroup('percent_position', trans('settings.localisation.percent.title'), 'percent', $percent_positions, null, [])); ?>

                    </div>

                    <div class="tab-pane tab-margin" id="invoice">
                        <?php echo e(Form::textGroup('invoice_number_prefix', trans('settings.invoice.prefix'), 'font', [])); ?>


                        <?php echo e(Form::textGroup('invoice_number_digit', trans('settings.invoice.digit'), 'text-width', [])); ?>


                        <?php echo e(Form::textGroup('invoice_number_next', trans('settings.invoice.next'), 'chevron-right', [])); ?>


                        <?php echo e(Form::invoice_text('invoice_item', trans('settings.invoice.item_name'), 'font', $item_names, null, [], 'invoice_item_input', null)); ?>


                        <?php echo e(Form::invoice_text('invoice_price', trans('settings.invoice.price_name'), 'font', $price_names, null, [], 'invoice_price_input', null)); ?>


                        <?php echo e(Form::invoice_text('invoice_quantity', trans('settings.invoice.quantity_name'), 'font', $quantity_names, null, [], 'invoice_quantity_input', null)); ?>


                        <?php echo e(Form::fileGroup('invoice_logo', trans('settings.invoice.logo'))); ?>

                    </div>

                    <div class="tab-pane tab-margin" id="default">
                        <?php echo e(Form::selectGroup('default_account', trans('settings.default.account'), 'university', $accounts, null, [])); ?>


                        <?php echo e(Form::selectGroup('default_currency', trans('settings.default.currency'), 'exchange', $currencies, null, [])); ?>


                        <?php echo e(Form::selectGroup('default_tax', trans('settings.default.tax'), 'percent', $taxes, null, [])); ?>


                        <?php echo e(Form::selectGroup('default_payment_method', trans('settings.default.payment'), 'credit-card', $payment_methods, setting('general.default_payment_method'), [])); ?>


                        <?php echo e(Form::selectGroup('default_locale', trans('settings.default.language'), 'flag', language()->allowed(), null, [])); ?>

                    </div>

                    <div class="tab-pane tab-margin" id="email">
                        <?php echo e(Form::selectGroup('email_protocol', trans('settings.email.protocol'), 'share', $email_protocols, null, [])); ?>


                        <?php echo e(Form::textGroup('email_sendmail_path', trans('settings.email.sendmail_path'), 'road', [])); ?>


                        <?php echo e(Form::textGroup('email_smtp_host', trans('settings.email.smtp.host'), 'paper-plane-o', [])); ?>


                        <?php echo e(Form::textGroup('email_smtp_port', trans('settings.email.smtp.port'), 'paper-plane-o', [])); ?>


                        <?php echo e(Form::textGroup('email_smtp_username', trans('settings.email.smtp.username'), 'paper-plane-o', [])); ?>


                        <?php echo e(Form::textGroup('email_smtp_password', trans('settings.email.smtp.password'), 'paper-plane-o', ['type' => 'password'])); ?>


                        <?php echo e(Form::selectGroup('email_smtp_encryption', trans('settings.email.smtp.encryption'), 'paper-plane-o', ['' => trans('settings.email.smtp.none'), 'ssl' => 'SSL', 'tls' => 'TLS'], null, [])); ?>

                    </div>

                    <div class="tab-pane tab-margin" id="scheduling">
                        <?php echo e(Form::radioGroup('send_invoice_reminder', trans('settings.scheduling.send_invoice'))); ?>


                        <?php echo e(Form::textGroup('schedule_invoice_days', trans('settings.scheduling.invoice_days'), 'calendar-check-o', [])); ?>


                        <?php echo e(Form::radioGroup('send_bill_reminder', trans('settings.scheduling.send_bill'))); ?>


                        <?php echo e(Form::textGroup('schedule_bill_days', trans('settings.scheduling.bill_days'), 'calendar-check-o', [])); ?>


                        <?php echo e(Form::radioGroup('send_item_reminder', trans('settings.scheduling.send_item_reminder'))); ?>


                        <?php echo e(Form::textGroup('schedule_item_stocks', trans('settings.scheduling.item_stocks'), 'cubes', [])); ?>


                        <div class="col-sm-6">
                            <label for="cron_command" class="control-label"><?php echo e(trans('settings.scheduling.cron_command')); ?></label>
                            <pre>php /path-to-akaunting/artisan schedule:run >> /dev/null 2>&1</pre>
                        </div>

                        <?php echo e(Form::textGroup('schedule_time', trans('settings.scheduling.schedule_time'), 'clock-o', [])); ?>

                    </div>

                    <div class="tab-pane tab-margin" id="appearance">
                        <?php echo e(Form::selectGroup('admin_theme', trans('settings.appearance.theme'), 'paint-brush', ['skin-green-light' => trans('settings.appearance.light'), 'skin-black' => trans('settings.appearance.dark')], null, [])); ?>


                        <?php echo e(Form::selectGroup('list_limit', trans('settings.appearance.list_limit'), 'columns', ['10' => '10', '25' => '25', '50' => '50', '100' => '100'], null, [])); ?>


                        <?php echo e(Form::radioGroup('use_gravatar', trans('settings.appearance.use_gravatar'))); ?>

                    </div>

                    <div class="tab-pane tab-margin" id="system">
                        <?php echo e(Form::selectGroup('session_handler', trans('settings.system.session.handler'), 'database', ['file' => trans('settings.system.session.file'), 'database' => trans('settings.system.session.database')], null, [])); ?>


                        <?php echo e(Form::textGroup('session_lifetime', trans('settings.system.session.lifetime'), 'clock-o', [])); ?>


                        <?php echo e(Form::textGroup('file_size', trans('settings.system.file_size'), 'upload', [])); ?>


                        <?php echo e(Form::textGroup('file_types', trans('settings.system.file_types'), 'file-o', [])); ?>

                    </div>

                    <?php if (app('laratrust')->can('update-settings-settings')) : ?>
                    <div class="setting-buttons">
                        <div class="form-group no-margin">
                            <?php echo Form::button('<span class="fa fa-save"></span> &nbsp;' . trans('general.save'), ['type' => 'submit', 'class' => 'btn btn-success  button-submit', 'data-loading-text' => trans('general.loading')]); ?>

                            <a href="<?php echo e(URL::previous()); ?>" class="btn btn-default"><span class="fa fa-times-circle"></span> &nbsp;<?php echo e(trans('general.cancel')); ?></a>
                        </div>
                    </div>
                    <?php endif; // app('laratrust')->can ?>
                </div>
            </div>
        </div>

        <?php echo Form::close(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('public/js/bootstrap-fancyfile.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('public/css/bootstrap-fancyfile.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript">
        var text_yes = '<?php echo e(trans('general.yes')); ?>';
        var text_no = '<?php echo e(trans('general.no')); ?>';

        $(document).ready(function() {
            $('#email_smtp_password').attr('type', 'password');

            $("#date_format").select2({
                placeholder: "<?php echo e(trans('general.form.select.field', ['field' => trans('settings.localisation.date.format')])); ?>"
            });

            $("#date_separator").select2({
                placeholder: "<?php echo e(trans('general.form.select.field', ['field' => trans('settings.localisation.date.separator')])); ?>"
            });

            $("#timezone").select2({
                placeholder: "<?php echo e(trans('general.form.select.field', ['field' => trans('settings.localisation.timezone')])); ?>"
            });

            $("#percent_position").select2({
                placeholder: "<?php echo e(trans('general.form.select.field', ['field' => trans('settings.localisation.percent.title')])); ?>"
            });

            $("#default_account").select2({
                placeholder: "<?php echo e(trans('general.form.select.field', ['field' => trans('settings.default.account')])); ?>"
            });

            $("#default_currency").select2({
                placeholder: "<?php echo e(trans('general.form.select.field', ['field' => trans('settings.default.currency')])); ?>"
            });

            $("#default_tax").select2({
                placeholder: "<?php echo e(trans('general.form.select.field', ['field' => trans('settings.default.tax')])); ?>"
            });

            $("#default_payment_method").select2({
                placeholder: "<?php echo e(trans('general.form.select.field', ['field' => trans('settings.default.payment')])); ?>"
            });

            $("#default_locale").select2({
                placeholder: "<?php echo e(trans('general.form.select.field', ['field' => trans('settings.default.language')])); ?>"
            });

            $("#admin_theme").select2({
                placeholder: "<?php echo e(trans('general.form.select.field', ['field' => trans('settings.appearance.theme')])); ?>"
            });

            $("#email_protocol").select2({
                placeholder: "<?php echo e(trans('general.form.select.field', ['field' => trans('settings.email.protocol')])); ?>"
            });

            $("#list_limit").select2({
                placeholder: "<?php echo e(trans('general.form.select.field', ['field' => trans('settings.appearance.list_limit')])); ?>"
            });

            $("#session_handler").select2({
                placeholder: "<?php echo e(trans('general.form.select.field', ['field' => trans('settings.system.session.handler')])); ?>"
            });

            $('#company_logo').fancyfile({
                text  : '<?php echo e(trans('general.form.select.file')); ?>',
                style : 'btn-default',
                <?php if($setting['company_logo']): ?>
                placeholder : '<?php echo e($setting['company_logo']->basename); ?>',
                <?php else: ?>
                placeholder : '<?php echo e(trans('general.form.no_file_selected')); ?>',
                <?php endif; ?>
            });

            <?php if($setting['company_logo']): ?>
                company_logo_html  = '<span class="company_logo">';
                company_logo_html += '    <a href="<?php echo e(url('uploads/' . $setting['company_logo']->id . '/download')); ?>">';
                company_logo_html += '        <span id="download-company_logo" class="text-primary">';
                company_logo_html += '            <i class="fa fa-file-<?php echo e($setting['company_logo']->aggregate_type); ?>-o"></i> <?php echo e($setting['company_logo']->basename); ?>';
                company_logo_html += '        </span>';
                company_logo_html += '    </a>';
                company_logo_html += '    <?php echo Form::open(['id' => 'company_logo-' . $setting['company_logo']->id, 'method' => 'DELETE', 'url' => [url('uploads/' . $setting['company_logo']->id)], 'style' => 'display:inline']); ?>';
                company_logo_html += '    <a id="remove-company_logo" href="javascript:void();">';
                company_logo_html += '        <span class="text-danger"><i class="fa fa fa-times"></i></span>';
                company_logo_html += '    </a>';
                company_logo_html += '    <input type="hidden" name="page" value="setting" />';
                company_logo_html += '    <input type="hidden" name="key" value="general.company_logo" />';
                company_logo_html += '    <input type="hidden" name="value" value="<?php echo e($setting['company_logo']->id); ?>" />';
                company_logo_html += '    <?php echo Form::close(); ?>';
                company_logo_html += '</span>';
    
                $('#company .fancy-file .fake-file').append(company_logo_html);
    
                $(document).on('click', '#remove-company_logo', function (e) {
                    confirmDelete("#company_logo-<?php echo $setting['company_logo']->id; ?>", "<?php echo trans('general.attachment'); ?>", "<?php echo trans('general.delete_confirm', ['name' => '<strong>' . $setting['company_logo']->basename . '</strong>', 'type' => strtolower(trans('general.attachment'))]); ?>", "<?php echo trans('general.cancel'); ?>", "<?php echo trans('general.delete'); ?>");
                });
            <?php endif; ?>

            var invoice_file = false;

            $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
                var target = $(e.target).attr("href");

                if (target == '#invoice' && !invoice_file) {
                    $(target + ' #invoice_logo').fancyfile({
                        text  : '<?php echo e(trans('general.form.select.file')); ?>',
                        style : 'btn-default',
                        <?php if($setting['invoice_logo']): ?>
                        placeholder : '<?php echo e($setting['invoice_logo']->basename); ?>',
                        <?php else: ?>
                        placeholder : '<?php echo e(trans('general.form.no_file_selected')); ?>',
                        <?php endif; ?>
                    });

                    <?php if($setting['invoice_logo']): ?>
                    invoice_logo_html  = '<span class="invoice_logo">';
                    invoice_logo_html += '    <a href="<?php echo e(url('uploads/' . $setting['invoice_logo']->id . '/download')); ?>">';
                    invoice_logo_html += '        <span id="download-invoice_logo" class="text-primary">';
                    invoice_logo_html += '            <i class="fa fa-file-<?php echo e($setting['invoice_logo']->aggregate_type); ?>-o"></i> <?php echo e($setting['invoice_logo']->basename); ?>';
                    invoice_logo_html += '        </span>';
                    invoice_logo_html += '    </a>';
                    invoice_logo_html += '    <?php echo Form::open(['id' => 'invoice_logo-' . $setting['invoice_logo']->id, 'method' => 'DELETE', 'url' => [url('uploads/' . $setting['invoice_logo']->id)], 'style' => 'display:inline']); ?>';
                    invoice_logo_html += '    <a id="remove-invoice_logo" href="javascript:void();">';
                    invoice_logo_html += '        <span class="text-danger"><i class="fa fa fa-times"></i></span>';
                    invoice_logo_html += '    </a>';
                    invoice_logo_html += '    <input type="hidden" name="page" value="setting" />';
                    invoice_logo_html += '    <input type="hidden" name="key" value="general.invoice_logo" />';
                    invoice_logo_html += '    <input type="hidden" name="value" value="<?php echo e($setting['invoice_logo']->id); ?>" />';
                    invoice_logo_html += '    <?php echo Form::close(); ?>';
                    invoice_logo_html += '</span>';

                    $(target + ' .fancy-file .fake-file').append(invoice_logo_html);

                    $(document).on('click', '#remove-invoice_logo', function (e) {
                        confirmDelete("#invoice_logo-<?php echo $setting['invoice_logo']->id; ?>", "<?php echo trans('general.attachment'); ?>", "<?php echo trans('general.delete_confirm', ['name' => '<strong>' . $setting['invoice_logo']->basename . '</strong>', 'type' => strtolower(trans('general.attachment'))]); ?>", "<?php echo trans('general.cancel'); ?>", "<?php echo trans('general.delete'); ?>");
                    });
                    <?php endif; ?>

                    invoice_file = true;
                }
            });

            $("select[name='email_protocol']").on('change', function() {
                var selection = $(this).val();

                if (selection == 'mail' || selection == 'log') {
                    $("input[name='email_sendmail_path']").prop('disabled', true);
                    $("input[name='email_smtp_host']").prop('disabled', true);
                    $("input[name='email_smtp_username']").prop('disabled', true);
                    $("input[name='email_smtp_password']").prop('disabled', true);
                    $("input[name='email_smtp_port']").prop('disabled', true);
                    $("select[name='email_smtp_encryption']").prop('disabled', true);
                } else if(selection == 'sendmail') {
                    $("input[name='email_sendmail_path']").prop('disabled', false);
                    $("input[name='email_smtp_host']").prop('disabled', true);
                    $("input[name='email_smtp_username']").prop('disabled', true);
                    $("input[name='email_smtp_password']").prop('disabled', true);
                    $("input[name='email_smtp_port']").prop('disabled', true);
                    $("select[name='email_smtp_encryption']").prop('disabled', true);
                } else if (selection == 'smtp') {
                    $("input[name='email_sendmail_path']").prop('disabled', true);
                    $("input[name='email_smtp_host']").prop('disabled', false);
                    $("input[name='email_smtp_username']").prop('disabled', false);
                    $("input[name='email_smtp_password']").prop('disabled', false);
                    $("input[name='email_smtp_port']").prop('disabled', false);
                    $("select[name='email_smtp_encryption']").prop('disabled', false);
                }
            });

            $("select[name='email_protocol']").trigger('change');
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>