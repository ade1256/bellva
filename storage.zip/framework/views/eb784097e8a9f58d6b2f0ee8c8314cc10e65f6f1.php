<?php $__env->startSection('title', trans('auth.login')); ?>
<?php $__env->startSection('message', trans('auth.login_to')); ?>

<?php $__env->startSection('content'); ?>
<form role="form" method="POST" action="<?php echo e(url('auth/login')); ?>">
    <?php echo e(csrf_field()); ?>


    <?php echo $__env->yieldPushContent('email_input_start'); ?>
    <div class="form-group has-feedback<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
        <input name="email" type="email" class="form-control" placeholder="<?php echo e(trans('general.email')); ?>" required autofocus>
        <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
        <?php if($errors->has('email')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('email')); ?></strong>
            </span>
        <?php endif; ?>
    </div>
    <?php echo $__env->yieldPushContent('email_input_end'); ?>

    <?php echo $__env->yieldPushContent('password_input_start'); ?>
    <div class="form-group has-feedback<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
        <input name="password" type="password" class="form-control" placeholder="<?php echo e(trans('auth.password.current')); ?>" required>
        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
        <?php if($errors->has('password')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('password')); ?></strong>
            </span>
        <?php endif; ?>
    </div>
    <?php echo $__env->yieldPushContent('password_input_end'); ?>

    <div class="row">
        <?php echo $__env->yieldPushContent('remember_input_start'); ?>
        <div class="col-sm-8">
            <div class="checkbox icheck">
                <label>
                    <input name="remember" type="checkbox" <?php echo e(old('remember') ? 'checked' : ''); ?>> &nbsp;<?php echo e(trans('auth.remember_me')); ?>

                </label>
            </div>
        </div>
        <?php echo $__env->yieldPushContent('remember_input_end'); ?>
        <!-- /.col -->

        <div class="col-sm-4">
            <button type="submit" class="btn btn-success btn-block btn-flat"><?php echo e(trans('auth.login')); ?></button>
        </div>
        <!-- /.col -->
    </div>
</form>

<a href="<?php echo e(url('auth/forgot')); ?>"><?php echo e(trans('auth.forgot_password')); ?></a><br>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<!-- iCheck -->
<script src="<?php echo e(asset('vendor/almasaeed2010/adminlte/plugins/iCheck/icheck.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('css'); ?>
<!-- iCheck -->
<link rel="stylesheet" href="<?php echo e(asset('vendor/almasaeed2010/adminlte/plugins/iCheck/square/green.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(function () {
        $('input').iCheck({
            checkboxClass: 'icheckbox_square-green',
            radioClass: 'iradio_square-green',
            increaseArea: '20%' // optional
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>