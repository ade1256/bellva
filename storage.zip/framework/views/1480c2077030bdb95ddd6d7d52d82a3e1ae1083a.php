<html lang="<?php echo e(setting('general.default_locale')); ?>">
    <?php echo $__env->make('partials.invoice.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <body onload="window.print();">
        <?php echo $__env->yieldPushContent('body_start'); ?>

        <?php echo $__env->yieldContent('content'); ?>

        <?php echo $__env->yieldPushContent('body_end'); ?>
    </body>
</html>
