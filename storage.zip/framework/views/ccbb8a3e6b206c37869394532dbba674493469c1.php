<?php $__env->startSection('header', trans('install.steps.language')); ?>

<?php $__env->startSection('content'); ?>
    <div class="form-group">
        <div class="col-md-12">
            <select name="lang" id="lang" size="17" class="form-control">
                <?php $__currentLoopData = language()->allowed(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($code); ?>" <?php if($code == 'en-GB'): ?> <?php echo e('selected="selected"'); ?> <?php endif; ?>><?php echo e($name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.install', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>