<div class="box-body">
    <?php echo $chart->render(); ?>


    <hr>

    <div class="table table-responsive">
        <table class="table table-bordered table-striped table-hover" id="tbl-report-incomes">
            <thead>
            <tr>
                <th><?php echo e(trans_choice('general.categories', 1)); ?></th>
                <?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th class="text-right"><?php echo e($date); ?></th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
            </thead>
            <tbody>
            <?php if($incomes): ?>
                <?php $__currentLoopData = $incomes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category_id =>  $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($categories[$category_id]); ?></td>
                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td class="text-right"><?php echo money($item['amount'], setting('general.default_currency'), true); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <tr>
                    <td colspan="13">
                        <h5 class="text-center"><?php echo e(trans('general.no_records')); ?></h5>
                    </td>
                </tr>
            <?php endif; ?>
            </tbody>
            <tfoot>
            <tr>
                <th><?php echo e(trans_choice('general.totals', 1)); ?></th>
                <?php $__currentLoopData = $totals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $total): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th class="text-right"><?php echo money($total['amount'], $total['currency_code'], true); ?></th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
            </tfoot>
        </table>
    </div>
</div>

<?php $__env->startPush('js'); ?>
<?php echo Charts::assets(); ?>

<?php $__env->stopPush(); ?>
