<html lang="<?php echo e(setting('general.default_locale')); ?>">
    <?php echo $__env->make('partials.admin.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php $__env->startPush('css'); ?>
    <!-- Bootstrap 3 print fix -->
    <link rel="stylesheet" href="<?php echo e(asset('public/css/bootstrap3-print-fix.css?v=1.2')); ?>">
    <?php $__env->stopPush(); ?>

    <body onload="window.print();" class="print-width">
        <?php echo $__env->yieldPushContent('body_start'); ?>

        <?php echo $__env->yieldContent('content'); ?>

        <?php echo $__env->yieldPushContent('body_end'); ?>
    </body>
</html>
