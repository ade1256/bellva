<?php $__env->startSection('title', trans('general.wizard')); ?>

<?php $__env->startSection('content'); ?>
<!-- Default box -->
<div class="box box-solid">
    <div class="box-body">
        <div class="stepwizard">
            <div class="stepwizard-row setup-panel">
                <div class="stepwizard-step col-xs-3">
                    <a href="<?php echo e(url('wizard/companies')); ?>" type="button" class="btn btn-default btn-circle">1</a>
                    <p><small><?php echo e(trans_choice('general.companies', 1)); ?></small></p>
                </div>
                <div class="stepwizard-step col-xs-3">
                    <a href="<?php echo e(url('wizard/currencies')); ?>" type="button" class="btn btn-default btn-circle">2</a>
                    <p><small><?php echo e(trans_choice('general.currencies', 2)); ?></small></p>
                </div>
                <div class="stepwizard-step col-xs-3">
                    <a href="<?php echo e(url('wizard/taxes')); ?>" type="button" class="btn btn-default btn-circle">3</a>
                    <p><small><?php echo e(trans_choice('general.taxes', 2)); ?></small></p>
                </div>
                <div class="stepwizard-step col-xs-3">
                    <a href="#step-4" type="button" class="btn btn-success btn-circle">4</a>
                    <p><small><?php echo e(trans_choice('general.finish', 1)); ?></small></p>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row" style="margin-top: 50px;">
    <div class="col-md-12 no-padding-right text-center">
        <a href="<?php echo e(url('/')); ?>" class="btn btn-lg btn-success"><span class="fa fa-dashboard"></span> &nbsp;<?php echo e(trans('general.go_to', ['name' => trans('general.dashboard')])); ?></a>
    </div>
</div>

<div class="row">
    <div class="col-md-12 no-padding-right">
        <div class="content-header no-padding-left">
            <h3><?php echo e(trans('modules.recommended_apps')); ?></h3>
        </div>

        <?php if($modules): ?>
            <?php $__currentLoopData = $modules->data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('partials.modules.item', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-12 no-padding-left">
                <ul class="pager nomargin">
                    <?php if($modules->current_page < $modules->last_page): ?>
                        <li class="next"><a href="<?php echo e(url(request()->path())); ?>?page=<?php echo e($modules->current_page + 1); ?>" class="btn btn-default btn-sm"><?php echo e(trans('pagination.next')); ?></a></li>
                    <?php endif; ?>
                    <?php if($modules->current_page > 1): ?>
                        <li class="previous"><a href="<?php echo e(url(request()->path())); ?>?page=<?php echo e($modules->current_page - 1); ?>" class="btn btn-default btn-sm"><?php echo e(trans('pagination.previous')); ?></a></li>
                    <?php endif; ?>
                </ul>
            </div>
        <?php else: ?>
            <div class="box box-success">
                <div class="box-body">
                    <p class="col-md-12" style="margin-top: 15px">
                        <?php echo e(trans('modules.no_apps')); ?>

                    </p>
                    <p class="col-md-12" style="margin-top: 20px">
                        <small><?php echo trans('modules.developer'); ?></small>
                    </p>
                </div>
                <!-- /.box-body -->
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('public/css/modules.css?v=' . version('short'))); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    var text_yes = '<?php echo e(trans('general.yes')); ?>';
    var text_no = '<?php echo e(trans('general.no')); ?>';

    $(document).ready(function() {

    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.wizard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>