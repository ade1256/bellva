<?php $__env->startSection('title', trans_choice('general.reconciliations', 2)); ?>

<?php if (app('laratrust')->can('create-banking-reconciliations')) : ?>
<?php $__env->startSection('new_button'); ?>
<span class="new-button"><a href="<?php echo e(route('reconciliations.create')); ?>" class="btn btn-success btn-sm"><span class="fa fa-plus"></span> &nbsp;<?php echo e(trans('general.add_new')); ?></a></span>
<?php $__env->stopSection(); ?>
<?php endif; // app('laratrust')->can ?>

<?php $__env->startSection('content'); ?>
<!-- Default box -->
<div class="box box-success">
    <div class="box-header with-border">
        <?php echo Form::open(['url' => 'banking/reconciliations', 'role' => 'form', 'method' => 'GET']); ?>

        <div id="items" class="pull-left box-filter">
            <span class="title-filter hidden-xs"><?php echo e(trans('general.search')); ?>:</span>
            <?php echo Form::select('accounts[]', $accounts, request('accounts'), ['id' => 'filter-accounts', 'class' => 'form-control input-filter input-lg', 'multiple' => 'multiple']); ?>

            <?php echo Form::button('<span class="fa fa-filter"></span> &nbsp;' . trans('general.filter'), ['type' => 'submit', 'class' => 'btn btn-sm btn-default btn-filter']); ?>

        </div>
        <div class="pull-right">
            <span class="title-filter hidden-xs"><?php echo e(trans('general.show')); ?>:</span>
            <?php echo Form::select('limit', $limits, request('limit', setting('general.list_limit', '25')), ['class' => 'form-control input-filter input-sm', 'onchange' => 'this.form.submit()']); ?>

        </div>
        <?php echo Form::close(); ?>

    </div>
    <!-- /.box-header -->

    <div class="box-body">
        <div class="table table-responsive">
            <table class="table table-striped table-hover" id="tbl-reconciliations">
                <thead>
                    <tr>
                        <th class="col-md-2"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('created_at', trans('general.created_date')));?></th>
                        <th class="col-md-3"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('account_id', trans_choice('general.accounts', 1)));?></th>
                        <th class="col-md-3 hidden-xs"><?php echo e(trans('general.period')); ?></th>
                        <th class="col-md-2 text-right amount-space"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('closing_balance', trans('reconciliations.closing_balance')));?></th>
                        <th class="col-md-1 hidden-xs"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('enabled', trans_choice('general.statuses', 1)));?></th>
                        <th class="col-md-1 text-center"><?php echo e(trans('general.actions')); ?></th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $reconciliations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><a href="<?php echo e(route('reconciliations.edit', $item->id)); ?>"><?php echo e(Date::parse($item->created_at)->format($date_format)); ?></a></td>
                        <td><?php echo e($item->account->name); ?></td>
                        <td class="hidden-xs"><?php echo e(Date::parse($item->started_at)->format($date_format)); ?> - <?php echo e(Date::parse($item->ended_at)->format($date_format)); ?></td>
                        <td class="text-right amount-space"><?php echo money($item->closing_balance, $item->account->currency_code, true); ?></td>
                        <td class="hidden-xs">
                            <?php if($item->reconciled): ?>
                                <span class="label label-success"><?php echo e(trans('reconciliations.reconciled')); ?></span>
                            <?php else: ?>
                                <span class="label label-danger"><?php echo e(trans('reconciliations.unreconciled')); ?></span>
                            <?php endif; ?>
                        </td>
                        <td class="text-center">
                            <div class="btn-group">
                                <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" data-toggle-position="left" aria-expanded="false">
                                    <i class="fa fa-ellipsis-h"></i>
                                </button>
                                <ul class="dropdown-menu dropdown-menu-right">
                                    <li><a href="<?php echo e(route('reconciliations.edit', $item->id)); ?>"><?php echo e(trans('general.edit')); ?></a></li>
                                    <?php if (app('laratrust')->can('delete-banking-reconciliations')) : ?>
                                    <li class="divider"></li>
                                    <li><?php echo Form::deleteLink($item, 'banking/reconciliations'); ?></li>
                                    <?php endif; // app('laratrust')->can ?>
                                </ul>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <!-- /.box-body -->

    <div class="box-footer">
        <?php echo $__env->make('partials.admin.pagination', ['items' => $reconciliations, 'type' => 'reconciliations'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <!-- /.box-footer -->
</div>
<!-- /.box -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    $(document).ready(function(){
        $("#filter-accounts").select2({
            placeholder: "<?php echo e(trans('general.form.select.field', ['field' => trans_choice('general.accounts', 1)])); ?>"
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>