<?php $__env->startSection('title', trans('general.wizard')); ?>

<?php $__env->startSection('content'); ?>
<!-- Default box -->
<div class="box box-solid">
    <div class="box-body">
        <div class="stepwizard">
            <div class="stepwizard-row setup-panel">
                <div class="stepwizard-step col-xs-3">
                    <a href="#step-1" type="button" class="btn btn-success btn-circle">1</a>
                    <p><small><?php echo e(trans_choice('general.companies', 1)); ?></small></p>
                </div>
                <div class="stepwizard-step col-xs-3">
                    <button type="button" class="btn btn-default btn-circle" disabled="disabled">2</button>
                    <p><small><?php echo e(trans_choice('general.currencies', 2)); ?></small></p>
                </div>
                <div class="stepwizard-step col-xs-3">
                    <button type="button" class="btn btn-default btn-circle" disabled="disabled">3</button>
                    <p><small><?php echo e(trans_choice('general.taxes', 2)); ?></small></p>
                </div>
                <div class="stepwizard-step col-xs-3">
                    <button type="button" class="btn btn-default btn-circle" disabled="disabled">4</button>
                    <p><small><?php echo e(trans_choice('general.finish', 1)); ?></small></p>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="box box-success">
    <div id="wizard-loading"></div>

    <?php echo Form::model($company, ['method' => 'PATCH', 'files' => true, 'url' => ['wizard/companies'], 'role' => 'form', 'class' => 'form-loading-button']); ?>


    <div class="box-header with-border">
        <h3 class="box-title"><?php echo e(trans_choice('general.companies', 1)); ?></h3>
    </div>
    <!-- /.box-header -->

    <div class="box-body">
        <div class="col-md-12 <?php echo (!setting('general.api_token', null)) ?: 'hidden'; ?>">
            <div class="form-group required <?php echo e($errors->has('api_token') ? 'has-error' : ''); ?>">
                <?php echo Form::label('sale_price', trans('modules.api_token'), ['class' => 'control-label']); ?>

                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-key"></i></span>
                    <?php echo Form::text('api_token', setting('general.api_token', null), ['class' => 'form-control', 'required' => 'required', 'placeholder' => trans('general.form.enter', ['field' => trans('modules.api_token')])]); ?>

                </div>
                <?php echo $errors->first('api_token', '<p class="help-block">:message</p>'); ?>

            </div>
            <p>
                <?php echo trans('modules.token_link'); ?>

            </p>
            </br>
        </div>

        <?php echo e(Form::textGroup('company_tax_number', trans('general.tax_number'), 'percent', [])); ?>


        <?php echo e(Form::textGroup('company_phone', trans('settings.company.phone'), 'phone', [])); ?>


        <?php echo e(Form::textareaGroup('company_address', trans('settings.company.address'))); ?>


        <?php echo e(Form::fileGroup('company_logo', trans('settings.company.logo'))); ?>

    </div>
    <!-- /.box-body -->

    <div class="box-footer">
        <div class="col-md-12">
            <div class="form-group no-margin">
                <?php echo Form::button('<span class="fa fa-save"></span> &nbsp;' . trans('general.save'), ['type' => 'submit', 'class' => 'btn btn-success  button-submit', 'data-loading-text' => trans('general.loading')]); ?>

                <a href="<?php echo e(url('wizard/currencies')); ?>" id="wizard-skip" class="btn btn-default"><span class="fa fa-share"></span> &nbsp;<?php echo e(trans('general.skip')); ?></a>
            </div>
        </div>
    </div>
    <!-- /.box-footer -->

    <?php echo Form::close(); ?>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('public/js/bootstrap-fancyfile.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('public/css/bootstrap-fancyfile.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    var text_yes = '<?php echo e(trans('general.yes')); ?>';
    var text_no = '<?php echo e(trans('general.no')); ?>';

    $(document).ready(function() {
        $('#company_logo').fancyfile({
            text  : '<?php echo e(trans('general.form.select.file')); ?>',
            style : 'btn-default',
            <?php if($company->company_logo): ?>
            placeholder : '<?php echo e($company->company_logo->basename); ?>',
            <?php else: ?>
            placeholder : '<?php echo e(trans('general.form.no_file_selected')); ?>',
            <?php endif; ?>
        });

        <?php if($company->company_logo): ?>
        company_logo_html  = '<span class="company_logo">';
        company_logo_html += '    <a href="<?php echo e(url('uploads/' . $company->company_logo->id . '/download')); ?>">';
        company_logo_html += '        <span id="download-company_logo" class="text-primary">';
        company_logo_html += '            <i class="fa fa-file-<?php echo e($company->company_logo->aggregate_type); ?>-o"></i> <?php echo e($company->company_logo->basename); ?>';
        company_logo_html += '        </span>';
        company_logo_html += '    </a>';
        company_logo_html += '    <?php echo Form::open(['id' => 'company_logo-' . $company->company_logo->id, 'method' => 'DELETE', 'url' => [url('uploads/' . $company->company_logo->id)], 'style' => 'display:inline']); ?>';
        company_logo_html += '    <a id="remove-company_logo" href="javascript:void();">';
        company_logo_html += '        <span class="text-danger"><i class="fa fa fa-times"></i></span>';
        company_logo_html += '    </a>';
        company_logo_html += '    <input type="hidden" name="page" value="setting" />';
        company_logo_html += '    <input type="hidden" name="key" value="general.company_logo" />';
        company_logo_html += '    <input type="hidden" name="value" value="<?php echo e($company->company_logo->id); ?>" />';
        company_logo_html += '    <?php echo Form::close(); ?>';
        company_logo_html += '</span>';

        $('.form-group.col-md-6 .fancy-file .fake-file').append(company_logo_html);

        $(document).on('click', '#remove-company_logo', function (e) {
            confirmDelete("#company_logo-<?php echo $company->company_logo->id; ?>", "<?php echo trans('general.attachment'); ?>", "<?php echo trans('general.delete_confirm', ['name' => '<strong>' . $company->company_logo->basename . '</strong>', 'type' => strtolower(trans('general.attachment'))]); ?>", "<?php echo trans('general.cancel'); ?>", "<?php echo trans('general.delete'); ?>");
        });
        <?php endif; ?>
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.wizard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>