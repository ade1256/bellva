<button type="button" class="btn btn-sm btn-default btn-filter date-range-btn">
    <span>
      <i class="fa fa-<?php echo e($icon); ?>"></i> <?php echo e($text); ?>

    </span>
    <i class="fa fa-caret-down"></i>
    <?php echo Form::hidden($name, null, []); ?>

</button>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    $(document).ready(function(){
        $('.date-range-btn').daterangepicker(
            {
                ranges   : {
                    '<?php echo e(trans("general.date_range.today")); ?>'       : [moment(), moment()],
                    '<?php echo e(trans("general.date_range.yesterday")); ?>'   : [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                    '<?php echo e(trans("general.date_range.last_days", ["day" => "7"])); ?>' : [moment().subtract(6, 'days'), moment()],
                    '<?php echo e(trans("general.date_range.last_days", ["day" => "30"])); ?>': [moment().subtract(29, 'days'), moment()],
                    '<?php echo e(trans("general.date_range.this_month")); ?>'  : [moment().startOf('month'), moment().endOf('month')],
                    '<?php echo e(trans("general.date_range.last_month")); ?>'  : [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
                },
                startDate: moment().subtract(29, 'days'),
                endDate  : moment()
            },
            function (start, end) {
                $('input[name=<?php echo e($name); ?>]').val(start.format('YYYY-MM-DD') + '_' + end.format('YYYY-MM-DD'));

                date_format = convertDateFormat('<?php echo e(setting('general.date_format')); ?>', ' ');
                $('.date-range-btn span').html(start.format(date_format) + ' - ' + end.format(date_format));
            }
        );

        <?php if(request($name)): ?>
        var setDate = '<?php echo e(request($name)); ?>';
        var setDates = setDate.split('_');

        date_format = convertDateFormat('<?php echo e(setting('general.date_format')); ?>', ' ');

        start_date = moment(setDates[0], 'YYYY-MM-DD'); //new Date(setDates[0]);
        finish_date = moment(setDates[1], 'YYYY-MM-DD'); //new Date(setDates[1]);

        $('.date-range-btn span').html(start_date.format(date_format) + ' - ' + finish_date.format(date_format));
        <?php endif; ?>
    });
</script>
<?php $__env->stopPush(); ?>
