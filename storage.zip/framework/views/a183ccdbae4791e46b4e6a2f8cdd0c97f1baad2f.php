<?php $__env->startSection('title', trans_choice('general.modules', 2)); ?>

<?php $__env->startSection('new_button'); ?>
    <span class="new-button"><a href="<?php echo e(url('apps/token/create')); ?>" class="btn btn-success btn-sm"><span class="fa fa-key"></span> &nbsp;<?php echo e(trans('modules.api_token')); ?></a></span>
    <span class="new-button"><a href="<?php echo e(url('apps/my')); ?>" class="btn btn-default btn-sm"><span class="fa fa-user"></span> &nbsp;<?php echo e(trans('modules.my_apps')); ?></a></span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.modules.bar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row module">
        <div class="col-md-12">
            <div class="col-md-8 no-padding-left">
                <div class="content-header no-padding-left">
                    <h3><?php echo e($module->name); ?></h3>

                    <div class="pull-right rating">
                        <?php for($i = 1; $i <= $module->vote; $i++): ?>
                            <i class="fa fa-star fa-lg"></i>
                        <?php endfor; ?>
                        <?php for($i = $module->vote; $i < 5; $i++): ?>
                            <i class="fa fa-star-o fa-lg"></i>
                        <?php endfor; ?>
                    </div>
                </div>

                <div class="nav-tabs-custom">
                    <ul class="nav nav-tabs">
                        <li class="active"><a href="#description" data-toggle="tab" aria-expanded="true"><?php echo e(trans('general.description')); ?></a></li>
                        <?php if($module->installation): ?>
                        <li class=""><a href="#installation" data-toggle="tab" aria-expanded="false"><?php echo e(trans('modules.tab.installation')); ?></a></li>
                        <?php endif; ?>
                        <?php if($module->faq): ?>
                        <li class=""><a href="#faq" data-toggle="tab" aria-expanded="false"><?php echo e(trans('modules.tab.faq')); ?></a></li>
                        <?php endif; ?>
                        <?php if($module->changelog): ?>
                        <li class=""><a href="#changelog" data-toggle="tab" aria-expanded="false"><?php echo e(trans('modules.tab.changelog')); ?></a></li>
                        <?php endif; ?>
                        <li><a href="#review" data-toggle="tab" aria-expanded="false"><?php echo e(trans('modules.tab.reviews')); ?> <?php if($module->total_review): ?> (<?php echo e($module->total_review); ?>) <?php endif; ?></a></li>
                    </ul>

                    <div class="tab-content">
                        <div class="tab-pane active" id="description">
                            <?php echo $module->description; ?>


                            <?php if($module->screenshots || $module->video): ?>
                                <div id="carousel-screenshot-generic" class="carousel slide" data-ride="carousel">
                                    <div class="carousel-inner">
                                        <?php if($module->video): ?>
                                            <?php 
                                            if (strpos($module->video->link, '=') !== false) {
                                                $code = explode('=', $module->video->link);
                                                $code[1]= str_replace('&list', '', $code[1]);

                                                if (empty($status)) {
                                                    $status = 5;
                                                } else {
                                                    $status = 1;
                                                } 
                                             ?>

                                            <div class="item <?php if($status == 5): ?> <?php echo e('active'); ?> <?php endif; ?>">
                                                <iframe width="100%" height="410px" src="https://www.youtube-nocookie.com/embed/<?php echo e($code[1]); ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

                                                <div class="image-description text-center">
                                                    <?php echo e($module->name); ?>

                                                </div>
                                            </div>
                                            <?php  }  ?>
                                        <?php endif; ?>

                                        <?php $__currentLoopData = $module->screenshots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $screenshot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php  if (empty($status)) { $status = 5; } else { $status = 1; }  ?>
                                            <div class="item <?php if($status == 5): ?> <?php echo e('active'); ?> <?php endif; ?>">
                                                <a href="<?php echo e($screenshot->path_string); ?>" data-toggle="lightbox" data-gallery="<?php echo e($module->slug); ?>">
                                                    <img class="img-fluid d-block w-100" src="<?php echo e($screenshot->path_string); ?>" alt="<?php echo e($screenshot->alt_attribute); ?>">
                                                </a>

                                                <div class="image-description text-center">
                                                    <?php echo e($screenshot->description); ?>

                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <div class="carousel-navigation-message">
                                            <?php if(($module->video && (count($module->screenshots) > 1)) || (!$module->video && (count($module->screenshots) > 1))): ?>
                                            <a href="#carousel-screenshot-generic" class="left carousel-control" role="button" data-slide="prev">
                                                <i class="fa fa-chevron-left"></i>
                                                <span class="sr-only"><?php echo e(trans('pagination.previous')); ?></span>
                                            </a>
                                            <a href="#carousel-screenshot-generic" class="right carousel-control" role="button" data-slide="next">
                                                <i class="fa fa-chevron-right"></i>
                                                <span class="sr-only"><?php echo e(trans('pagination.next')); ?></span>
                                            </a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                        <?php if($module->installation): ?>
                        <div class="tab-pane" id="installation">
                            <?php echo $module->installation; ?>

                        </div>
                        <?php endif; ?>
                        <?php if($module->faq): ?>
                        <div class="tab-pane" id="faq">
                            <?php echo $module->faq; ?>

                        </div>
                        <?php endif; ?>
                        <?php if($module->changelog): ?>
                        <div class="tab-pane" id="changelog">
                            <?php echo $module->changelog; ?>

                        </div>
                        <?php endif; ?>
                        <div class="tab-pane" id="review">
                            <div id="reviews" class="clearfix">
                                <?php if(!$module->reviews): ?>
                                <?php echo e(trans('modules.reviews.na')); ?>

                                <?php endif; ?>
                            </div>

                            <hr>

                            <?php if(!empty($module->review_action)): ?>
                                <a href="<?php echo e($module->review_action); ?>" class="btn btn-success" target="_blank">
                                    <?php echo e(trans('modules.reviews.button.add')); ?>

                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="content-header no-padding-left">
                    <h3><?php echo e(trans_choice('general.actions', 1)); ?></h3>
                </div>

                <div class="box box-success">
                    <div class="box-body">
                        <div class="text-center">
                            <div style="margin: 10px; font-size: 24px;">
                                <?php if($module->price == '0.0000'): ?>
                                    <?php echo e(trans('modules.free')); ?>

                                <?php else: ?>
                                    <?php if(isset($module->special_price)): ?>
                                        <del><?php echo e($module->price); ?></del>
                                        <?php echo e($module->special_price); ?>

                                    <?php else: ?>
                                        <?php echo e($module->price); ?>

                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <!-- /.box-body -->

                    <div class="box-footer">
                        <?php if($installed): ?>
                            <?php if (app('laratrust')->can('delete-modules-item')) : ?>
                            <a href="<?php echo e(url('apps/' . $module->slug . '/uninstall')); ?>" class="btn btn-block btn-danger"><?php echo e(trans('modules.button.uninstall')); ?></a>
                            <?php endif; // app('laratrust')->can ?>
                            <?php if (app('laratrust')->can('update-modules-item')) : ?>
                            <?php if($enable): ?>
                                <a href="<?php echo e(url('apps/' . $module->slug . '/disable')); ?>" class="btn btn-block btn-warning"><?php echo e(trans('modules.button.disable')); ?></a>
                            <?php else: ?>
                                <a href="<?php echo e(url('apps/' . $module->slug . '/enable')); ?>" class="btn btn-block btn-success"><?php echo e(trans('modules.button.enable')); ?></a>
                            <?php endif; ?>
                            <?php endif; // app('laratrust')->can ?>
                        <?php else: ?>
                            <?php if (app('laratrust')->can('create-modules-item')) : ?>
                            <?php if($module->install): ?>
                            <a href="<?php echo e($module->action_url); ?>" class="btn btn-success btn-block" id="install-module">
                                <?php echo e(trans('modules.install')); ?>

                            </a>
                            <?php else: ?>
                            <a href="<?php echo e($module->action_url); ?>" class="btn btn-success btn-block" target="_blank">
                                <?php echo e(trans('modules.buy_now')); ?>

                            </a>
                            <?php endif; ?>
                            <?php endif; // app('laratrust')->can ?>
                        <?php endif; ?>

                        <?php if($module->purchase_faq): ?>
                        </br>
                        <div class="text-center">
                            <a href="#" id="button-purchase-faq"><?php echo e(trans('modules.tab.faq')); ?></a>
                        </div>
                        <?php endif; ?>
                    </div>
                    <!-- /.box-footer -->
                </div>
                <!-- /.box -->

                <div class="content-header no-padding-left">
                    <h3><?php echo e(trans('modules.about')); ?></h3>
                </div>

                <div class="box box-success">
                    <div class="box-body">
                        <table class="table table-striped">
                            <tbody>
                                <?php if($module->vendor_name): ?>
                                <tr>
                                    <th><?php echo e(trans_choice('general.vendors', 1)); ?></th>
                                    <td class="text-right"><a href="<?php echo e(url('apps/vendors/' . $module->vendor->slug)); ?>"><?php echo e($module->vendor_name); ?></a></td>
                                </tr>
                                <?php endif; ?>
                                <?php if($module->version): ?>
                                <tr>
                                    <th><?php echo e(trans('footer.version')); ?></th>
                                    <td class="text-right"><?php echo e($module->version); ?></td>
                                </tr>
                                <?php endif; ?>
                                <?php if($module->created_at): ?>
                                <tr>
                                    <th><?php echo e(trans('modules.added')); ?></th>
                                    <td class="text-right"><?php echo e(Date::parse($module->created_at)->format($date_format)); ?></td>
                                </tr>
                                <?php endif; ?>
                                <?php if($module->updated_at): ?>
                                <tr>
                                    <th><?php echo e(trans('modules.updated')); ?></th>
                                    <td class="text-right"><?php echo e(Date::parse($module->updated_at)->diffForHumans()); ?></td>
                                </tr>
                                <?php endif; ?>
                                <?php if($module->compatibility): ?>
                                <tr>
                                    <th><?php echo e(trans('modules.compatibility')); ?></th>
                                    <td class="text-right"><?php echo e($module->compatibility); ?></td>
                                </tr>
                                <?php endif; ?>
                                <?php if($module->category): ?>
                                <tr>
                                    <th><?php echo e(trans_choice('general.categories', 1)); ?></th>
                                    <td class="text-right"><a href="<?php echo e(url('apps/categories/' . $module->category->slug)); ?>"><?php echo e($module->category->name); ?></a></td>
                                </tr>
                                <?php endif; ?>

                                <tr>
                                    <th><?php echo e(trans('modules.documentation')); ?></th>
                                    <td class="text-right">
                                        <?php if($module->documentation): ?>
                                            <a href="<?php echo e(url('apps/docs/' . $module->slug)); ?>"><?php echo e(trans('modules.view')); ?></a></td>
                                        <?php else: ?>
                                            <?php echo e(trans('general.na')); ?>

                                        <?php endif; ?>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->
            </div>
        </div>
    </div>

    <?php if($module->purchase_faq): ?>
    <?php echo $module->purchase_faq; ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('public/js/lightbox/ekko-lightbox.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('public/css/ekko-lightbox.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('style'); ?>
    <style type="text/css">
    .nav-tabs-custom img {
        display: block;
        max-width: 100%;
        height: auto;
    }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript">
        var step = new Array();
        var total = 0;
        var path = '';

        $(document).ready(function() {
            $('.carousel').carousel({
                interval: false,
                keyboard: true
            });

            <?php if($module->reviews): ?>
            getReviews('', '1');
            <?php endif; ?>

            $('#install-module').on('click', function(e) {
                e.preventDefault();
                e.stopPropagation();

                path = $(this).attr('href');

                startInstallation();

                $.ajax({
                    url: '<?php echo e(url("apps/steps")); ?>',
                    type: 'post',
                    dataType: 'json',
                    data: {name: '<?php echo e($module->name); ?>', version: '<?php echo e($module->version); ?>'},
                    headers: { 'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>' },
                    success: function(json) {
                        if (json['errorr']) {
                            $('#progress-bar').addClass('progress-bar-danger');
                            $('#progress-text').html('<div class="text-danger">' + json['error'] + '</div>');
                        }

                        if (json['step']) {
                            step = json['step'];
                            total = step.length;

                            next();
                        }
                    }
                });
            });
        });

        $(document).on('click', '#reviews .pagination li a', function (e) {
            e.preventDefault();
            e.stopPropagation();

            path = $(this).attr('href');
            page = $(this).data('page');

            getReviews(path, page);
        });

        $(document).on('click', '[data-toggle="lightbox"]', function(e) {
            e.preventDefault();

            $(this).ekkoLightbox();
        });

        function next() {
            data = step.shift();

            if (data) {
                $('#progress-bar').css('width', (100 - (step.length / total) * 100) + '%');
                $('#progress-text').html('<span class="text-info">' + data['text'] + '</span>');

                setTimeout(function() {
                    $.ajax({
                        url: data.url,
                        type: 'post',
                        dataType: 'json',
                        data: {path: path, version: '<?php echo e($module->version); ?>'},
                        headers: { 'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>' },
                        success: function(json) {
                            if (json['errors']) {
                                $('#progress-bar').addClass('progress-bar-danger');
                                $('#progress-text').html('<div class="text-danger">' + json['errors'] + '</div>');
                            }

                            if (json['success']) {
                                $('#progress-bar').removeClass('progress-bar-danger');
                                $('#progress-bar').addClass('progress-bar-success');
                            }

                            if (json['data']['path']) {
                                path = json['data']['path'];
                            }

                            if (!json['errors'] && !json['installed']) {
                                next();
                            }

                            if (json['installed']) {
                                window.location = json['installed'];
                            }
                        },
                        error: function(xhr, ajaxOptions, thrownError) {
                            alert(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
                        }
                    });
                }, 800);
            }
        }

        function startInstallation() {
            $('#modal-installation').remove();

            modal  = '<div class="modal fade" id="modal-installation" style="display: none;">';
            modal += '  <div class="modal-dialog">';
            modal += '      <div class="modal-content">';
            modal += '          <div class="modal-header">';
            modal += '              <h4 class="modal-title"><?php echo e(trans('modules.installation.header')); ?></h4>';
            modal += '          </div>';
            modal += '          <div class="modal-body">';
            modal += '              <p></p>';
            modal += '              <p>';
            modal += '                 <div class="progress">';
            modal += '                  <div id="progress-bar" class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%">';
            modal += '                      <span class="sr-only"><?php echo e(trans('modules.installation.start', ['module' => $module->name])); ?></span>';
            modal += '                  </div>';
            modal += '                 </div>';
            modal += '                 <div id="progress-text"></div>';
            modal += '              </p>';
            modal += '          </div>';
            modal += '      </div>';
            modal += '  </div>';
            modal += '</div>';

            $('body').append(modal);

            $('#modal-installation').modal('show');
        }

        function getReviews(path, page) {
            $.ajax({
                url: '<?php echo e(url("apps/" . $module->slug . "/reviews")); ?>',
                type: 'post',
                dataType: 'json',
                data: {path: path, page: page},
                headers: { 'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>' },
                beforeSend: function() {
                    $('#reviews').append('<div id="loading" class="text-center"><i class="fa fa-spinner fa-spin fa-5x checkout-spin"></i></div>');
                },
                complete : function() {
                    $('#loading').remove();
                },
                success: function(json) {
                    if (json['success']) {
                        $('#reviews #review-items').remove();
                        $('#reviews').append(json['html']);
                    }
                }
            });
        }

        <?php if($module->purchase_faq): ?>
        $(document).on('click', '#button-purchase-faq', function (e) {
            $('.app-faq-modal').modal('show');
        });
        <?php endif; ?>
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.modules', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>