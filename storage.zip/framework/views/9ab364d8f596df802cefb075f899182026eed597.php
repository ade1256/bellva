<?php echo $__env->yieldPushContent('pagination_start'); ?>

<?php if($items->firstItem()): ?>
    <div class="pull-left" style="margin-top: 7px;">
        <small><?php echo e(trans('pagination.showing', ['first' => $items->firstItem(), 'last' => $items->lastItem(), 'total' => $items->total(), 'type' => strtolower((isset($title)) ? $title : trans_choice('general.' . $type, 2))])); ?></small>
    </div>
    <div class="pull-right">
        <?php echo $items->appends(request()->except('page'))->links(); ?>

    </div>
<?php else: ?>
    <div class="pull-left">
        <small><?php echo e(trans('general.no_records')); ?></small>
    </div>
<?php endif; ?>

<?php echo $__env->yieldPushContent('pagination_end'); ?>