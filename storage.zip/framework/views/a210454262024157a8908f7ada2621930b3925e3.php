<?php echo $__env->yieldPushContent('header_start'); ?>

<header class="main-header">
    <!-- Logo -->
    <a href="<?php echo e(url('/')); ?>" class="logo">
        <?php if(setting('general.admin_theme', 'skin-green-light') == 'skin-green-light'): ?>
            <!-- mini logo for sidebar mini 50x50 pixels -->
            <span class="logo-mini"><img src="<?php echo e(asset('public/img/logo.png')); ?>" class="logo-image-mini" width="25" alt="Bellva Logo"></span>
            <!-- logo for regular state and mobile devices -->
            <span class="logo-lg"><img src="<?php echo e(asset('public/img/logo.png')); ?>" class="logo-image-lg" width="25" alt="Bellva Logo"> <b>Bellva</b></span>
        <?php else: ?>
            <!-- mini logo for sidebar mini 50x50 pixels -->
            <span class="logo-mini"><img src="<?php echo e(asset('public/img/logo.png')); ?>" class="logo-image-mini" width="25" alt="Bellva Logo"></span>
            <!-- logo for regular state and mobile devices -->
            <span class="logo-lg"><img src="<?php echo e(asset('public/img/logo.png')); ?>" class="logo-image-lg" width="25" alt="Bellva Logo"> <b>Bellva</b></span>
        <?php endif; ?>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
        <!-- Sidebar toggle button-->
        <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>
        </a>

        <ul class="add-new nav navbar-nav pull-left">
            <!-- Notifications: style can be found in dropdown.less -->
            <li class="dropdown add-new-menu">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                    <i class="fa fa-plus"></i>
                </a>
                <div class="dropdown-menu">
                    <ul class="list-inline">
                        <li>
                            <ul class="list-unstyled">
                                <li class="header"><i class="fa fa-money"></i> &nbsp;<span style="font-weight: 600;"><?php echo e(trans_choice('general.incomes', 1)); ?></span></li>
                                <li>
                                    <ul class="menu">
                                        <?php if (app('laratrust')->can('create-incomes-invoices')) : ?>
                                        <li><a href="<?php echo e(url('incomes/invoices/create')); ?>"><?php echo e(trans_choice('general.invoices', 1)); ?></a></li>
                                        <?php endif; // app('laratrust')->can ?>
                                        <?php if (app('laratrust')->can('create-incomes-revenues')) : ?>
                                        <li><a href="<?php echo e(url('incomes/revenues/create')); ?>"><?php echo e(trans_choice('general.revenues', 1)); ?></a></li>
                                        <?php endif; // app('laratrust')->can ?>
                                        <?php if (app('laratrust')->can('create-incomes-customers')) : ?>
                                        <li><a href="<?php echo e(url('incomes/customers/create')); ?>"><?php echo e(trans_choice('general.customers', 1)); ?></a></li>
                                        <?php endif; // app('laratrust')->can ?>
                                    </ul>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <ul class="list-unstyled">
                                <li class="header"><i class="fa fa-shopping-cart"></i> &nbsp;<span style="font-weight: 600;"><?php echo e(trans_choice('general.expenses', 1)); ?></span></li>
                                <li>
                                    <ul class="menu">
                                        <?php if (app('laratrust')->can('create-expenses-bills')) : ?>
                                        <li><a href="<?php echo e(url('expenses/bills/create')); ?>"><?php echo e(trans_choice('general.bills', 1)); ?></a></li>
                                        <?php endif; // app('laratrust')->can ?>
                                        <?php if (app('laratrust')->can('create-expenses-payments')) : ?>
                                        <li><a href="<?php echo e(url('expenses/payments/create')); ?>"><?php echo e(trans_choice('general.payments', 1)); ?></a></li>
                                        <?php endif; // app('laratrust')->can ?>
                                        <?php if (app('laratrust')->can('create-expenses-vendors')) : ?>
                                        <li><a href="<?php echo e(url('expenses/vendors/create')); ?>"><?php echo e(trans_choice('general.vendors', 1)); ?></a></li>
                                        <?php endif; // app('laratrust')->can ?>
                                    </ul>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <ul class="list-unstyled">
                                <li class="header"><i class="fa fa-university"></i> &nbsp;<span style="font-weight: 600;"><?php echo e(trans('general.banking')); ?></span></li>
                                <li>
                                    <ul class="menu">
                                        <?php if (app('laratrust')->can('create-banking-accounts')) : ?>
                                        <li><a href="<?php echo e(url('banking/accounts/create')); ?>"><?php echo e(trans_choice('general.accounts', 1)); ?></a></li>
                                        <?php endif; // app('laratrust')->can ?>
                                        <?php if (app('laratrust')->can('create-banking-transfers')) : ?>
                                        <li><a href="<?php echo e(url('banking/transfers/create')); ?>"><?php echo e(trans_choice('general.transfers', 1)); ?></a></li>
                                        <?php endif; // app('laratrust')->can ?>
                                        <?php if (app('laratrust')->can('create-banking-reconciliations')) : ?>
                                        <li><a href="<?php echo e(url('banking/reconciliations/create')); ?>"><?php echo e(trans_choice('general.reconciliations', 1)); ?></a></li>
                                        <?php endif; // app('laratrust')->can ?>
                                    </ul>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </li>
        </ul>

        <?php echo $__env->yieldPushContent('header_navbar_left'); ?>

        <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
                <?php echo $__env->yieldPushContent('header_navbar_right'); ?>

                <?php if (app('laratrust')->can('read-notifications')) : ?>
                <!-- Notifications: style can be found in dropdown.less -->
                <li class="dropdown notifications-menu">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        <i class="fa fa-bell-o"></i>
                        <?php if($notifications): ?>
                        <span class="label label-warning"><?php echo e($notifications); ?></span>
                        <?php endif; ?>
                    </a>
                    <ul class="dropdown-menu">
                        <li class="header"><?php echo e(trans_choice('header.notifications.counter', $notifications, ['count' => $notifications])); ?></li>
                        <li>
                            <!-- inner menu: contains the actual data -->
                            <ul class="menu">
                                <?php if(count($bills)): ?>
                                <li>
                                    <a href="<?php echo e(url('auth/users/' . $user->id . '/read-bills')); ?>">
                                        <i class="fa fa-shopping-cart text-red"></i> <?php echo e(trans_choice('header.notifications.upcoming_bills', count($bills), ['count' => count($bills)])); ?>

                                    </a>
                                </li>
                                <?php endif; ?>
                                <?php if(count($invoices)): ?>
                                <li>
                                    <a href="<?php echo e(url('auth/users/' . $user->id . '/read-invoices')); ?>">
                                        <i class="fa fa-money text-green"></i> <?php echo e(trans_choice('header.notifications.overdue_invoices', count($invoices), ['count' => count($invoices)])); ?>

                                    </a>
                                </li>
                                <?php endif; ?>
                                <?php if(count($items)): ?>
                                <li>
                                    <a href="<?php echo e(url('auth/users/' . $user->id . '/read-items')); ?>">
                                        <i class="fa fa-cubes text-red"></i> <?php echo e(trans_choice('header.notifications.items_stock', count($items), ['count' => count($items)])); ?>

                                    </a>
                                </li>
                                <?php endif; ?>
                                <?php if(count($items_reminder)): ?>
                                <li>
                                    <a href="<?php echo e(url('auth/users/' . $user->id . '/read-items')); ?>">
                                        <i class="fa fa-cubes text-red"></i> <?php echo e(trans_choice('header.notifications.items_reminder', count($items_reminder), ['count' => count($items_reminder)])); ?>

                                    </a>
                                </li>
                                <?php endif; ?>
                            </ul>
                        </li>
                        <li class="footer"><a href="#"><?php echo e(trans('header.notifications.view_all')); ?></a></li>
                    </ul>
                </li>
                <?php endif; // app('laratrust')->can ?>
                <!-- Tasks: style can be found in dropdown.less -->
                <li class="dropdown tasks-menu">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        <i class="fa fa-flag-o"></i>
                    </a>
                    <ul class="dropdown-menu">
                        <li class="header"><?php echo e(trans('header.change_language')); ?></li>
                        <li>
                            <!-- inner menu: contains the actual data -->
                            <?php echo language()->flags(); ?>

                        </li>
                    </ul>
                </li>
               
               
                <!-- User Account: style can be found in dropdown.less -->
                <li class="dropdown user user-menu">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        <?php if($user->picture): ?>
                            <?php if(setting('general.use_gravatar', '0') == '1'): ?>
                                <img src="<?php echo e($user->picture); ?>" class="user-image" alt="User Image">
                            <?php else: ?>
                                <img src="<?php echo e(Storage::url($user->picture->id)); ?>" class="user-image" alt="User Image">
                            <?php endif; ?>
                        <?php else: ?>
                            <i class="fa fa-user-o"></i>
                        <?php endif; ?>
                        <?php if(!empty($user->name)): ?>
                            <span class="hidden-xs"><?php echo e($user->name); ?></span>
                        <?php endif; ?>
                    </a>
                    <ul class="dropdown-menu">
                        <!-- User image -->
                        <li class="user-header">
                            <?php if($user->picture): ?>
                                <?php if(setting('general.use_gravatar', '0') == '1'): ?>
                                    <img src="<?php echo e($user->picture); ?>" class="img-circle" alt="User Image">
                                <?php else: ?>
                                    <img src="<?php echo e(Storage::url($user->picture->id)); ?>" class="img-circle" alt="User Image">
                                <?php endif; ?>
                            <?php else: ?>
                                <i class="fa fa-4 fa-user-o" style="color: #fff; font-size: 7em;"></i>
                            <?php endif; ?>
                            <p>
                                <?php if(!empty($user->name)): ?>
                                <?php echo e($user->name); ?>

                                <?php endif; ?>
                                <small><?php echo e(trans('header.last_login', ['time' => $user->last_logged_in_at])); ?></small>
                            </p>
                        </li>
                        <!-- Menu Body -->
                        <li class="user-body">
                            <div class="row">
                                <?php if (app('laratrust')->can('read-auth-users')) : ?>
                                <div class="col-xs-4 text-center">
                                    <a href="<?php echo e(url('auth/users')); ?>"><?php echo e(trans_choice('general.users', 2)); ?></a>
                                </div>
                                <?php endif; // app('laratrust')->can ?>
                                <?php if (app('laratrust')->can('read-auth-roles')) : ?>
                                <div class="col-xs-4 text-center">
                                    <a href="<?php echo e(url('auth/roles')); ?>"><?php echo e(trans_choice('general.roles', 2)); ?></a>
                                </div>
                                <?php endif; // app('laratrust')->can ?>
                                <?php if (app('laratrust')->can('read-auth-permissions')) : ?>
                                <div class="col-xs-4 text-center">
                                    <a href="<?php echo e(url('auth/permissions')); ?>"><?php echo e(trans_choice('general.permissions', 2)); ?></a>
                                </div>
                                <?php endif; // app('laratrust')->can ?>
                            </div>
                            <!-- /.row -->
                        </li>
                        <!-- Menu Footer-->
                        <li class="user-footer">
                            <?php if (app('laratrust')->can('read-auth-profile')) : ?>
                            <div class="pull-left">
                                <a href="<?php echo e(url('auth/users/' . $user->id . '/edit')); ?>" class="btn btn-default btn-flat"><?php echo e(trans('auth.profile')); ?></a>
                            </div>
                            <?php endif; // app('laratrust')->can ?>
                            <div class="pull-right">
                                <a href="<?php echo e(url('auth/logout')); ?>" class="btn btn-default btn-flat"><?php echo e(trans('auth.logout')); ?></a>
                            </div>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>
    </nav>
</header>

<?php echo $__env->yieldPushContent('header_end'); ?>
