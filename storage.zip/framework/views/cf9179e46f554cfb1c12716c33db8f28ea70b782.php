<?php echo $__env->yieldPushContent('footer_start'); ?>

<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>v1</b> beta
    </div>
    <strong>PT. Bellva</strong>: <a href="http://Bellva.com" target="_blank">Bellva Beer</a>
</footer>

<?php echo $__env->yieldPushContent('footer_end'); ?>
