<div class="col-md-3 no-padding-left">
    <div class="box box-success">
        <div class="box-header with-border">
            <h3 class="box-title"><a href="<?php echo e(url('apps/' . $module->slug)); ?>"><?php echo e($module->name); ?></a></h3>

            <?php if(isset($installed[$module->slug])): ?>
                <?php  $color = 'bg-green';  ?>

                <?php if(!$installed[$module->slug]): ?>
                    <?php  $color = 'bg-yellow';  ?>
                <?php endif; ?>
                <span class="module-installed">
                    <small class="label <?php echo e($color); ?>"><?php echo e(trans('modules.badge.installed')); ?></small>
                </span>
            <?php endif; ?>
            <!-- /.box-tools -->
        </div>
        <!-- /.box-header -->

        <div class="box-body text-center">
            <a href="<?php echo e(url('apps/' . $module->slug)); ?>">
                <?php $__currentLoopData = $module->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(($file->media_type == 'image') && ($file->pivot->zone == 'thumbnail')): ?>
                        <img src="<?php echo e($file->path_string); ?>" alt="<?php echo e($module->name); ?>" class="item-image">
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </a>
        </div>
        <!-- /.box-body -->

        <div class="box-footer">
            <div class="pull-left">
            <?php for($i = 1; $i <= $module->vote; $i++): ?>
                <i class="fa fa-star fa-lg"></i>
            <?php endfor; ?>
            <?php for($i = $module->vote; $i < 5; $i++): ?>
                <i class="fa fa-star-o fa-lg"></i>
            <?php endfor; ?>
            <?php if($module->total_review): ?>
                &nbsp; (<?php echo e($module->total_review); ?>)
            <?php endif; ?>
            </div>
            <div class="pull-right">
                <?php if($module->price == '0.0000'): ?>
                    <?php echo e(trans('modules.free')); ?>

                <?php else: ?>
                    <?php if(isset($module->special_price)): ?>
                        <del><?php echo e($module->price); ?></del>
                        <?php echo e($module->special_price); ?>

                    <?php else: ?>
                        <?php echo e($module->price); ?>

                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
        <!-- /.box-footer -->
    </div>
    <!-- /.box -->
</div>