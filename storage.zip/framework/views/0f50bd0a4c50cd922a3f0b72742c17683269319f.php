<?php $__env->startSection('title', trans_choice('general.invoices', 2)); ?>

<?php $__env->startSection('new_button'); ?>
<?php if (app('laratrust')->can('create-incomes-invoices')) : ?>
<span class="new-button"><a href="<?php echo e(url('incomes/invoices/create')); ?>" class="btn btn-success btn-sm"><span class="fa fa-plus"></span> &nbsp;<?php echo e(trans('general.add_new')); ?></a></span>
<span><a href="<?php echo e(url('common/import/incomes/invoices')); ?>" class="btn btn-default btn-sm"><span class="fa fa-download"></span> &nbsp;<?php echo e(trans('import.import')); ?></a></span>
<?php endif; // app('laratrust')->can ?>
<span><a href="<?php echo e(route('invoices.export', request()->input())); ?>" class="btn btn-default btn-sm"><span class="fa fa-upload"></span> &nbsp;<?php echo e(trans('general.export')); ?></a></span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Default box -->
<div class="box box-success">
    <div class="box-header with-border">
        <?php echo Form::open(['url' => 'incomes/invoices', 'role' => 'form', 'method' => 'GET']); ?>

        <div id="items" class="pull-left box-filter">
            <span class="title-filter hidden-xs"><?php echo e(trans('general.search')); ?>:</span>
            <?php echo Form::text('search', request('search'), ['class' => 'form-control input-filter input-sm', 'placeholder' => trans('general.search_placeholder')]); ?>

            <?php echo Form::select('customers[]', $customers, request('customers'), ['id' => 'filter-customers', 'class' => 'form-control input-filter input-lg', 'multiple' => 'multiple']); ?>

            <?php echo Form::select('categories[]', $categories, request('categories'), ['id' => 'filter-categories', 'class' => 'form-control input-filter input-lg', 'multiple' => 'multiple']); ?>

            <?php echo Form::dateRange('invoice_date', trans('invoices.invoice_date'), 'calendar', []); ?>

            <?php echo Form::select('statuses[]', $statuses, request('statuses'), ['id' => 'filter-statuses', 'class' => 'form-control input-filter input-lg', 'multiple' => 'multiple']); ?>

            <?php echo Form::button('<span class="fa fa-filter"></span> &nbsp;' . trans('general.filter'), ['type' => 'submit', 'class' => 'btn btn-sm btn-default btn-filter']); ?>

        </div>
        <div class="pull-right">
            <span class="title-filter hidden-xs"><?php echo e(trans('general.show')); ?>:</span>
            <?php echo Form::select('limit', $limits, request('limit', setting('general.list_limit', '25')), ['class' => 'form-control input-filter input-sm', 'onchange' => 'this.form.submit()']); ?>

        </div>
        <?php echo Form::close(); ?>

    </div>
    <!-- /.box-header -->
    <div class="box-body">
        <div class="table table-responsive">
            <table class="table table-striped table-hover" id="tbl-invoices">
                <thead>
                    <tr>
                        <th class="col-md-2"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('invoice_number', trans_choice('general.numbers', 1)));?></th>
                        <th class="col-md-2"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('customer_name', trans_choice('general.customers', 1)));?></th>
                        <th class="col-md-2 text-right amount-space"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('amount', trans('general.amount')));?></th>
                        <th class="col-md-2"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('invoiced_at', trans('invoices.invoice_date')));?></th>
                        <th class="col-md-2"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('due_at', trans('invoices.due_date')));?></th>
                        <th class="col-md-1"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('invoice_status_code', trans_choice('general.statuses', 1)));?></th>
                        <th class="col-md-1 text-center"><?php echo e(trans('general.actions')); ?></th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php  $paid = $item->paid;  ?>
                    <tr>
                        <td><a href="<?php echo e(url('incomes/invoices/' . $item->id . ' ')); ?>"><?php echo e($item->invoice_number); ?></a></td>
                        <td><?php echo e($item->customer_name); ?></td>
                        <td class="text-right amount-space"><?php echo money($item->amount, $item->currency_code, true); ?></td>
                        <td><?php echo e(Date::parse($item->invoiced_at)->format($date_format)); ?></td>
                        <td><?php echo e(Date::parse($item->due_at)->format($date_format)); ?></td>
                        <td><span class="label <?php echo e($item->status->label); ?>"><?php echo e(trans('invoices.status.' . $item->status->code)); ?></span></td>
                        <td class="text-center">
                            <div class="btn-group">
                                <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" data-toggle-position="left" aria-expanded="false">
                                    <i class="fa fa-ellipsis-h"></i>
                                </button>
                                <ul class="dropdown-menu dropdown-menu-right">
                                    <li><a href="<?php echo e(url('incomes/invoices/' . $item->id)); ?>"><?php echo e(trans('general.show')); ?></a></li>
                                    <?php if(!$item->reconciled): ?>
                                    <li><a href="<?php echo e(url('incomes/invoices/' . $item->id . '/edit')); ?>"><?php echo e(trans('general.edit')); ?></a></li>
                                    <?php endif; ?>
                                    <?php if (app('laratrust')->can('create-incomes-invoices')) : ?>
                                    <li class="divider"></li>
                                    <li><a href="<?php echo e(url('incomes/invoices/' . $item->id . '/duplicate')); ?>"><?php echo e(trans('general.duplicate')); ?></a></li>
                                    <?php endif; // app('laratrust')->can ?>
                                    <?php if (app('laratrust')->can('delete-incomes-invoices')) : ?>
                                    <?php if(!$item->reconciled): ?>
                                    <li class="divider"></li>
                                    <li><?php echo Form::deleteLink($item, 'incomes/invoices'); ?></li>
                                    <?php endif; ?>
                                    <?php endif; // app('laratrust')->can ?>
                                </ul>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <!-- /.box-body -->

    <div class="box-footer">
        <?php echo $__env->make('partials.admin.pagination', ['items' => $invoices, 'type' => 'invoices'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <!-- /.box-footer -->
</div>
<!-- /.box -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('vendor/almasaeed2010/adminlte/plugins/daterangepicker/moment.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/almasaeed2010/adminlte/plugins/daterangepicker/daterangepicker.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/almasaeed2010/adminlte/plugins/datepicker/bootstrap-datepicker.js')); ?>"></script>
<?php if(language()->getShortCode() != 'en'): ?>
<script src="<?php echo e(asset('vendor/almasaeed2010/adminlte/plugins/datepicker/locales/bootstrap-datepicker.' . language()->getShortCode() . '.js')); ?>"></script>
<?php endif; ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('vendor/almasaeed2010/adminlte/plugins/daterangepicker/daterangepicker.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('vendor/almasaeed2010/adminlte/plugins/datepicker/datepicker3.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    $(document).ready(function(){
        $("#filter-categories").select2({
            placeholder: "<?php echo e(trans('general.form.select.field', ['field' => trans_choice('general.categories', 1)])); ?>"
        });

        $("#filter-customers").select2({
            placeholder: "<?php echo e(trans('general.form.select.field', ['field' => trans_choice('general.customers', 1)])); ?>"
        });

        $("#filter-statuses").select2({
            placeholder: "<?php echo e(trans('general.form.select.field', ['field' => trans_choice('general.statuses', 1)])); ?>"
        });
    });
</script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>