<?php echo $__env->yieldPushContent('content_start'); ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <?php echo $__env->yieldPushContent('content_wrapper_start'); ?>

    <!-- Content Header (Page header) -->
    <section class="content-header content-center">
        <?php echo $__env->yieldPushContent('content_header_start'); ?>

        <h1>
            <?php echo $__env->yieldContent('title'); ?>
            <?php echo $__env->yieldContent('new_button'); ?>
            <?php if(!empty($suggestion_modules)): ?>
                <?php $__currentLoopData = $suggestion_modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s_module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="new-button">
                        <a href="<?php echo e(url($s_module->action_url) . '?' . http_build_query((array) $s_module->action_parameters)); ?>" class="btn btn-default btn-sm" target="<?php echo e($s_module->action_target); ?>"><span class="fa fa-rocket"></span> &nbsp;<?php echo e($s_module->name); ?></a>
                    </span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </h1>

        <?php echo $__env->yieldPushContent('content_header_end'); ?>
    </section>

    <!-- Main content -->
    <section class="content content-center">
        <?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php echo $__env->yieldPushContent('content_content_start'); ?>

        <?php echo $__env->yieldContent('content'); ?>

        <?php echo $__env->yieldPushContent('content_content_end'); ?>
    </section>
    <!-- /.content -->

    <?php echo $__env->yieldPushContent('content_wrapper_end'); ?>
</div>
<!-- /.content-wrapper -->

<script type="text/javascript">
    $('div.alert').not('.alert-important').delay(3000).fadeOut(350);
</script>

<?php echo $__env->yieldPushContent('content_end'); ?>