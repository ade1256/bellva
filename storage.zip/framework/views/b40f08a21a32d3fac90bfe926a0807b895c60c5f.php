<?php echo $__env->yieldPushContent($name . '_input_start'); ?>

<div class="<?php echo e($col); ?> input-group-invoice-text">
    <div class="form-group col-md-12 <?php echo e(isset($attributes['required']) ? 'required' : ''); ?> <?php echo e($errors->has($name) ? 'has-error' : ''); ?>">
        <?php echo Form::label($name, $text, ['class' => 'control-label']); ?>

        <div class="input-group">
            <div class="input-group-addon"><i class="fa fa-<?php echo e($icon); ?>"></i></div>
            <?php echo Form::select($name, $values, $selected, array_merge(['class' => 'form-control', 'placeholder' => trans('general.form.select.field', ['field' => $text])], $attributes)); ?>

        </div>
        <?php echo $errors->first($name, '<p class="help-block">:message</p>'); ?>

    </div>

    <div class="form-group col-md-6 hidden <?php echo e($errors->has('invoice_text_text') ? 'has-error' : ''); ?>">
        <?php echo Form::label($input_name, trans('settings.invoice.custom'), ['class' => 'control-label']); ?>

        <?php echo Form::text($input_name, $input_value, ['class' => 'form-control']); ?>

        <?php echo $errors->first($input_name, '<p class="help-block">:message</p>'); ?>

    </div>
</div>

<?php echo $__env->yieldPushContent($name . '_input_end'); ?>
