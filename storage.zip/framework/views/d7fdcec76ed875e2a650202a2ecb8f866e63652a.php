<?php echo $__env->yieldPushContent('save_buttons_start'); ?>

<div class="<?php echo e($col); ?>">
    <div class="form-group no-margin">
        <?php echo Form::button('<span class="fa fa-save"></span> &nbsp;' . trans('general.save'), ['type' => 'submit', 'class' => 'btn btn-success  button-submit', 'data-loading-text' => trans('general.loading')]); ?>

        <a href="<?php echo e(url($cancel)); ?>" class="btn btn-default"><span class="fa fa-times-circle"></span> &nbsp;<?php echo e(trans('general.cancel')); ?></a>
    </div>
</div>

<?php echo $__env->yieldPushContent('save_buttons_end'); ?>
